// src/components/grooming/GroomingCardGrid.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../Button'; // 공용 Button 컴포넌트 import
import styles from './GroomingCardGrid.module.css';

// 이미지 로딩 실패 시 표시할 기본 이미지 URL입니다.
const FALLBACK_IMAGE_SRC = 'https://picsum.photos/seed/grooming/400/300';

const GroomingCardGrid = ({ items = [] }) => {
  const navigate = useNavigate();
  if (!items.length) {
    // 필터링된 아이템이 없을 때 메시지를 표시합니다.
    // 이 로직은 GroomingPage에서 처리하는 것보다 여기서 처리하는 것이 더 적합할 수 있습니다.
    // 하지만 현재 GroomingPage에서 처리하고 있으므로, 여기서는 빈 그리드를 반환하거나
    // 아래와 같이 메시지를 표시할 수 있습니다.
    return <div className={styles.noResults}>조건에 맞는 미용실이 없습니다.</div>;
  }

  return (
    <div className={styles.gridContainer}>
      <div className={styles.grid}>
        {items.map(item => (
          <div key={item.id} className={styles.card}>
            <div className={styles.cardImage}>
              <img
                src={item.image || FALLBACK_IMAGE_SRC}
                alt={item.name}
                onError={(e) => {
                  e.currentTarget.src = FALLBACK_IMAGE_SRC;
                }}
              />
              {item.rating && (
                <div className={styles.rating}>
                  <span className={styles.star}>⭐</span>
                  {item.rating}
                </div>
              )}
            </div>

            <div className={styles.cardContent}>
              <h3 className={styles.name}>{item.name}</h3>
              <p className={styles.address}>{item.address}</p>

              {item.services && item.services.length > 0 && (
                <div className={styles.services}>
                  {item.services.slice(0, 3).map((service, index) => (
                    <span key={index} className={styles.serviceTag}>
                      {service}
                    </span>
                  ))}
                  {item.services.length > 3 && (
                    <span className={styles.moreServices}>
                      +{item.services.length - 3}개
                    </span>
                  )}
                </div>
              )}

              <div className={styles.cardFooter}>
                {item.phone && (
                  <div className={styles.phone}>
                    📞 {item.phone}
                  </div>
                )}
                {item.priceRange && (
                  <div className={styles.priceRange}>
                    {item.priceRange === 'low' ? '💰' :
                     item.priceRange === 'medium' ? '💰💰' : '💰💰💰'}
                  </div>
                )}
              </div>

              <div className={styles.cardActions}>
                <Button
                  variant="secondary"
                  className={styles.detailButton}
                  onClick={() => navigate(`/grooming/${item.id}`)}
                >
                  상세보기
                </Button>
                <button className={styles.bookingButton}>
                  예약하기
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GroomingCardGrid;