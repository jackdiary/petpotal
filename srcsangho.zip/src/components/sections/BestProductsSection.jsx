
// src/components/sections/BestProductsSection.jsx
// 베스트 상품을 표시하는 섹션 컴포넌트
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './BestProductsSection.module.css';
import petSuppliesData from '../../data/petSupplies.json'; // 반려용품 데이터 임포트

const BestProductsSection = () => {
  const [products, setProducts] = useState([]); // 상품 목록 상태
  const [loading, setLoading] = useState(true); // 로딩 상태
  const navigate = useNavigate(); // 페이지 이동을 위한 훅

  // 컴포넌트 마운트 시 베스트 상품 데이터 로드
  useEffect(() => {
    fetchBestProducts();
  }, []);

  // 베스트 상품 데이터를 가져오는 함수 (프론트엔드 전용)
  const fetchBestProducts = async () => {
    try {
      // 백엔드 API 호출 대신 로컬 JSON 데이터 사용
      // const response = await fetch('http://localhost:3001/api/pet-supplies/best?limit=4');
      // const data = await response.json();
      
      // JSON 데이터에서 베스트 상품만 필터링하여 상위 4개 선택
      const bestProducts = petSuppliesData
        .filter(product => product.isBest) // 베스트 상품만 필터링
        .slice(0, 4); // 상위 4개만 선택
      
      setProducts(bestProducts); // 상품 목록 상태 업데이트
    } catch (error) {
      console.error('베스트 상품 조회 실패:', error); // 오류 로그 출력
    } finally {
      setLoading(false); // 로딩 상태 종료
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'KRW'
    }).format(price);
  };

  const handleProductClick = (productId) => {
    navigate(`/pet-supplies/${productId}`);
  };

  const handleViewAllClick = () => {
    navigate('/pet-supplies');
  };

  if (loading) {
    return (
      <section className={styles.section}>
        <div className={styles.container}>
          <div className={styles.header}>
            <h2 className={styles.title}>이달의 베스트 상품</h2>
          </div>
          <div className={styles.loading}>상품을 불러오는 중...</div>
        </div>
      </section>
    );
  }

  return (
    <section className={styles.section}>
      <div className={styles.container}>
        <div className={styles.header}>
          <h2 className={styles.title}>이달의 베스트 상품</h2>
          <button onClick={handleViewAllClick} className={styles.viewMore}>
            전체보기 &gt;
          </button>
        </div>
        <div className={styles.grid}>
          {products.map((product) => (
            <div 
              key={product.id} 
              className={styles.card}
              onClick={() => handleProductClick(product.id)}
            >
              <div className={styles.imageWrapper}>
                <img 
                  src={product.imageUrl || 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400'} 
                  alt={product.name} 
                  className={styles.image} 
                />
                {product.isBest && (
                  <span className={styles.bestBadge}>BEST</span>
                )}
              </div>
              <div className={styles.cardBody}>
                <h3 className={styles.productName}>{product.name}</h3>
                <p className={styles.productDescription}>{product.description}</p>
                <div className={styles.productInfo}>
                  <p className={styles.productPrice}>{formatPrice(product.price)}</p>
                  {product.rating > 0 && (
                    <div className={styles.rating}>
                      <span className={styles.stars}>⭐</span>
                      <span className={styles.ratingText}>{product.rating}</span>
                    </div>
                  )}
                </div>
                {product.brand && (
                  <p className={styles.brand}>{product.brand}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestProductsSection;
