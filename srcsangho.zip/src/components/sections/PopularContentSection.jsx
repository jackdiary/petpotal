// src/components/sections/PopularContentSection.jsx
// 인기 콘텐츠 섹션을 표시하는 컴포넌트
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // 페이지 이동을 위한 훅
import styles from './PopularContentSection.module.css'; // 스타일 모듈 임포트

// 인기 콘텐츠에 사용할 랜덤 펫 이미지 URL 배열
const petImages = [
  'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=400',
  'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=400',
  'https://images.unsplash.com/photo-1551717743-49959800b1f6?w=400',
  'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400',
  'https://images.unsplash.com/photo-1574144611937-0df059b5ef3e?w=400',
  'https://images.unsplash.com/photo-1592194996308-7b43878e84a6?w=400',
  'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400',
  'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=400'
];

const PopularContentSection = () => {
  const [popularContent, setPopularContent] = useState([]); // 인기 콘텐츠 목록 상태
  const [loading, setLoading] = useState(true); // 로딩 상태
  const navigate = useNavigate(); // 페이지 이동을 위한 훅

  // 컴포넌트 마운트 시 인기 콘텐츠 데이터 로드
  useEffect(() => {
    fetchPopularContent();
  }, []);

  // 인기 콘텐츠 데이터를 가져오는 함수 (프론트엔드 전용)
  const fetchPopularContent = async () => {
    try {
      // 백엔드 API 호출 대신 로컬 JSON 데이터 사용
      // const response = await fetch('http://localhost:3001/api/community/posts?limit=20');
      // const data = await response.json();

      // 로컬 JSON 데이터 임포트
      const communityPostsData = await import('../../data/communityPosts.json');
      const posts = communityPostsData.default;

      // 조회수 기준으로 정렬하고 상위 4개 선택
      const sortedPosts = posts
        .sort((a, b) => b.views - a.views) // 조회수 내림차순 정렬
        .slice(0, 4) // 상위 4개만 선택
        .map((post, index) => ({
          ...post,
          image: petImages[index % petImages.length], // 랜덤 이미지 할당
          category: getCategoryName(post.boardKey), // 카테고리 이름 변환
          author: post.author_name || '익명' // 작성자 이름 설정
        }));

      setPopularContent(sortedPosts); // 인기 콘텐츠 상태 업데이트
    } catch (error) {
      console.error('인기 콘텐츠 조회 실패:', error); // 오류 로그 출력
      // 에러 시 빈 배열로 설정
      setPopularContent([]);
    } finally {
      setLoading(false); // 로딩 상태 종료
    }
  };

  const getCategoryName = (boardKey) => {
    switch (boardKey) {
      case 'free-talk': return '자유수다';
      case 'reviews': return '여행후기';
      case 'meetups': return '모임';
      case 'info': return '정보공유';
      default: return '커뮤니티';
    }
  };

  const handleContentClick = (post) => {
    const boardKey = post.boardKey || 'free-talk';
    navigate(`/community/${boardKey}/${post.id}`);
  };

  const handleViewAllClick = () => {
    navigate('/community');
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ko-KR', {
      month: 'short',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <section className={styles.section}>
        <div className={styles.container}>
          <div className={styles.header}>
            <h2 className={styles.title}>이달의 인기 콘텐츠</h2>
          </div>
          <div className={styles.loading}>콘텐츠를 불러오는 중...</div>
        </div>
      </section>
    );
  }

  return (
    <section className={styles.section}>
      <div className={styles.container}>
        <div className={styles.header}>
          <h2 className={styles.title}>이달의 인기 콘텐츠</h2>
          <button onClick={handleViewAllClick} className={styles.viewMore}>
            전체보기 &gt;
          </button>
        </div>
        <div className={styles.grid}>
          {popularContent.length > 0 ? (
            popularContent.map((content) => (
              <div
                key={content.id}
                className={styles.card}
                onClick={() => handleContentClick(content)}
              >
                <div className={styles.imageWrapper}>
                  <img src={content.image} alt={content.title} className={styles.image} />
                  <span className={styles.category}>{content.category}</span>
                  <div className={styles.stats}>
                    <span className={styles.views}>👁 {content.views}</span>
                    <span className={styles.likes}>❤ {content.likes}</span>
                  </div>
                </div>
                <div className={styles.cardBody}>
                  <h3 className={styles.cardTitle}>{content.title}</h3>
                  <div className={styles.meta}>
                    <p className={styles.author}>by {content.author}</p>
                    <p className={styles.date}>{formatDate(content.created_at)}</p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className={styles.noContent}>
              <p>아직 등록된 인기 콘텐츠가 없습니다.</p>
              <button onClick={handleViewAllClick} className={styles.createButton}>
                정보공유 게시판 보기
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default PopularContentSection;