// src/components/common/MapView.jsx

import React, { useEffect, useRef, useState } from 'react'; // React와 상태 관리를 위한 훅들을 가져옵니다.
import { loadKakaoMap } from '../../utils/loadKakaoMap'; // 카카오맵 스크립트를 동적으로 로드하는 유틸리티 함수를 가져옵니다.
import SimpleMapView from './SimpleMapView'; // 카카오맵 로드 실패 시 보여줄 대체 지도 컴포넌트를 가져옵니다.

const MapView = ({ userLocation, markers }) => { // 지도 뷰 컴포넌트입니다. 사용자 위치와 마커 정보를 props로 받습니다.
  const mapRef = useRef(null); // 지도를 담을 DOM 요소에 대한 참조(ref)입니다.
  const mapInstance = useRef(null); // 생성된 카카오맵 인스턴스를 저장하기 위한 참조입니다.
  const markerInstances = useRef([]); // 생성된 마커 인스턴스들을 저장하기 위한 참조입니다.
  const [kakaoMaps, setKakaoMaps] = useState(null); // 카카오맵 API 객체를 저장할 상태입니다.
  const [error, setError] = useState(null); // 오류 메시지를 저장할 상태입니다.
  const [isLoading, setIsLoading] = useState(true); // 로딩 상태를 관리합니다.

  // 1) 카카오맵 스크립트 로드
  useEffect(() => { // 컴포넌트가 처음 마운트될 때 한 번만 실행됩니다.
    // Vite 환경변수에서 API 키를 읽어옵니다.
    const apiKey = import.meta.env.VITE_KAKAO_JS_KEY;
    console.log('VITE_KAKAO_JS_KEY:', apiKey); // API 키가 제대로 로드되었는지 확인하기 위한 로그입니다.

    if (!apiKey) { // API 키가 없으면
      setError('카카오맵 API 키가 설정되지 않았습니다.'); // 오류 상태를 설정합니다.
      setIsLoading(false); // 로딩 상태를 종료합니다.
      return; // 함수 실행을 중단합니다.
    }

    loadKakaoMap(apiKey) // 스크립트 로드 함수를 호출합니다.
      .then(maps => { // 로드가 성공하면
        // autoload=false 옵션으로 로드했으므로, 수동으로 초기화해줍니다.
        window.kakao.maps.load(() => {
          setKakaoMaps(window.kakao.maps); // 로드된 카카오맵 API 객체를 상태에 저장합니다.
          setIsLoading(false); // 로딩 상태를 종료합니다.
        });
      })
      .catch(err => { // 로드 중 오류가 발생하면
        console.error('카카오맵 로드 실패:', err); // 콘솔에 오류를 기록합니다.
        setError(err.message); // 오류 메시지를 상태에 저장합니다.
        setIsLoading(false); // 로딩 상태를 종료합니다.
      });
  }, []); // 빈 배열을 의존성으로 전달하여 최초 렌더링 시에만 실행되도록 합니다.

  // 2) 지도 생성
  useEffect(() => { // 카카오맵 API가 로드되거나 로딩 상태, 사용자 위치가 변경될 때 실행됩니다.
    if (!kakaoMaps || !mapRef.current || isLoading) return; // 필요한 조건이 충족되지 않으면 함수를 종료합니다.

    try {
      if (typeof kakaoMaps.LatLng !== 'function') { // LatLng 생성자가 유효한지 확인합니다.
        throw new Error('LatLng 생성자를 찾을 수 없습니다.');
      }

      const center = userLocation // 지도의 중심 좌표를 설정합니다.
        ? new kakaoMaps.LatLng(userLocation.lat, userLocation.lng) // 사용자 위치가 있으면 해당 위치로 설정합니다.
        : new kakaoMaps.LatLng(37.5665, 126.9780); // 없으면 서울 시청을 기본값으로 설정합니다.

      mapInstance.current = new kakaoMaps.Map(mapRef.current, { // 지도 인스턴스를 생성합니다.
        center, // 중심 좌표
        level: 5, // 확대 레벨
      });

      // 줌 컨트롤(확대/축소 버튼)을 추가합니다.
      const zoomControl = new kakaoMaps.ZoomControl();
      mapInstance.current.addControl(zoomControl, kakaoMaps.ControlPosition.RIGHT); // 오른쪽에 배치합니다.
    } catch (err) { // 지도 생성 중 오류가 발생하면
      console.error('지도 생성 실패:', err); // 콘솔에 오류를 기록합니다.
      setError(`지도 생성에 실패했습니다: ${err.message}`); // 오류 상태를 설정합니다.
    }
  }, [kakaoMaps, isLoading, userLocation]); // 의존성 배열: 이 값들이 변경될 때마다 효과가 다시 실행됩니다.

  // 3) 사용자 위치 업데이트 시 지도 중심 이동
  useEffect(() => { // 사용자 위치가 변경될 때마다 실행됩니다.
    if (!mapInstance.current || !userLocation || !kakaoMaps || isLoading) return; // 필요한 조건이 충족되지 않으면 함수를 종료합니다.
    try {
      const center = new kakaoMaps.LatLng(userLocation.lat, userLocation.lng); // 새 중심 좌표를 생성합니다.
      mapInstance.current.panTo(center); // 지도의 중심을 부드럽게 이동시킵니다.
    } catch (err) { // 위치 이동 중 오류가 발생하면
      console.error('위치 이동 실패:', err); // 콘솔에 오류를 기록합니다.
    }
  }, [userLocation, kakaoMaps, isLoading]); // 의존성 배열

  // 로딩 상태 UI
  if (isLoading) {
    return (
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: '#f8f9fa', fontSize: '16px'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '24px', marginBottom: '10px' }}>🗺️</div>
          <div>카카오맵 로딩 중...</div>
        </div>
      </div>
    );
  }

  // 에러 발생 시 대체 지도 표시
  if (error) {
    console.warn('카카오맵 로드 실패, 대체 지도 사용:', error); // 콘솔에 경고를 기록합니다.
    return <SimpleMapView userLocation={userLocation} markers={markers} />; // 간단한 지도 컴포넌트를 렌더링합니다.
  }

  // 정상 렌더링
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      <div
        ref={mapRef} // 이 div가 지도를 담을 컨테이너가 됩니다.
        style={{
          position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: '#f0f0f0'
        }}
      />
      {/* 디버깅 및 상태 표시용 오버레이 UI */}
      <div style={{
        padding: 12, fontSize: 14, position: 'absolute',
        bottom: 10, right: 10, background: 'rgba(255,255,255,0.95)',
        borderRadius: 8, zIndex: 1000, boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
        color: 'gray'
      }}>
        <div style={{ fontWeight: 'bold' }}>🗺️ 카카오맵</div>
        <div style={{ fontSize: 12, marginTop: 4 }}>
          상태: {kakaoMaps ? '✅ 준비 완료' : '⏳ 초기화 중...'}
        </div>
        <div style={{ fontSize: 12,color: 'gray'}}>
          위치: {userLocation
            ? `${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)}`
            : '확인 중...'}
        </div>
        <div style={{ fontSize: 12, color: 'gray' }}>
          마커: {markers?.length || 0}개
        </div>
      </div>
    </div>
  );
};

export default MapView; // 컴포넌트를 내보냅니다.
