// src/components/common/BusinessList.jsx
import React, { useState } from 'react';
import BusinessListItem from './BusinessListItem';
import styles from './BusinessList.module.css';

const BusinessList = ({ items }) => {
  const [expandedItem, setExpandedItem] = useState(null);

  const handleToggle = (id) => {
    setExpandedItem(expandedItem === id ? null : id);
  };

  if (!items || items.length === 0) {
    return <div className={styles.noResults}>표시할 업체가 없습니다.</div>;
  }

  return (
    <ul className={styles.listContainer}>
      {items.map((item) => (
        <BusinessListItem key={item.id} item={item} isExpanded={expandedItem === item.id} onToggle={() => handleToggle(item.id)} />
      ))}
    </ul>
  );
};

export default BusinessList;