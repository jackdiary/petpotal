// src/pages/HomePage.jsx
// React 라이브러리를 가져옵니다.
import React from 'react';
// 홈페이지를 구성하는 다양한 섹션 컴포넌트들을 가져옵니다.
import HeroSection from '../components/sections/HeroSection';
import BestProductsSection from '../components/sections/BestProductsSection';
import PetSuppliesSection from '../components/sections/PetSuppliesSection';
import TrustSection from '../components/sections/TrustSection';
import PopularContentSection from '../components/sections/PopularContentSection';
import TestimonialSection from '../components/sections/TestimonialSection';
import LocationServiceSection from '../components/sections/LocationServiceSection';
import QuickCategorySection from '../components/sections/QuickCategorySection';
import NewsSection from '../components/sections/NewsSection';
// 이 페이지에만 적용될 CSS 모듈을 가져옵니다.
import styles from './HomePage.module.css';

// HomePage 컴포넌트 정의
const HomePage = () => {
  return (
    <div className={styles.homePage}>
      {/* 
        메인 레이아웃(App.jsx)에서 Header와 Footer가 관리되므로 여기서는 제거되었습니다.
      */}
      <main>
        {/* 각 섹션 컴포넌트들을 순서대로 렌더링합니다. */}
        <HeroSection />
        <BestProductsSection />
        <PetSuppliesSection />
        <TrustSection />
        <PopularContentSection />
        <TestimonialSection />
        <LocationServiceSection />
        <QuickCategorySection />
        <NewsSection />
      </main>
    </div>
  );
};

export default HomePage;