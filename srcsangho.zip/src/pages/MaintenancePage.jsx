// src/pages/MaintenancePage.jsx
// React 및 관련 훅들을 가져옵니다.
import React, { useState, useEffect } from 'react';
// 점검 상태를 관리하는 커스텀 컨텍스트 훅을 가져옵니다.
import { useMaintenance } from '../context/MaintenanceContext';
// 이 페이지에만 적용될 CSS 모듈을 가져옵니다.
import styles from './MaintenancePage.module.css';

// MaintenancePage 컴포넌트 정의
const MaintenancePage = () => {
  // MaintenanceContext에서 점검 설정과 남은 시간 계산 함수를 가져옵니다.
  const { maintenanceSettings, getTimeUntilMaintenanceEnd } = useMaintenance();
  const [timeLeft, setTimeLeft] = useState(null); // 남은 시간 상태
  const [currentTime, setCurrentTime] = useState(new Date()); // 현재 시간 상태

  // 1초마다 현재 시간과 남은 점검 시간을 업데이트하는 효과입니다.
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      const timeUntilEnd = getTimeUntilMaintenanceEnd();
      setTimeLeft(timeUntilEnd);
    }, 1000);

    // 컴포넌트가 언마운트될 때 타이머를 정리합니다.
    return () => clearInterval(timer);
  }, [getTimeUntilMaintenanceEnd]);

  // 점검 종료 시간을 보기 좋은 형식의 문자열로 변환하는 함수입니다.
  const formatEndTime = () => {
    if (!maintenanceSettings || !maintenanceSettings.endDate || !maintenanceSettings.endTime) {
      return '점검 종료 시간이 설정되지 않았습니다.';
    }

    const endDateTime = new Date(`${maintenanceSettings.endDate}T${maintenanceSettings.endTime}`);
    return endDateTime.toLocaleString('ko-KR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      weekday: 'long'
    });
  };

  // 점검 시작 시간과 종료 시간을 기준으로 현재 진행률(%)을 계산하는 함수입니다.
  const getProgressPercentage = () => {
    if (!maintenanceSettings || !maintenanceSettings.startDate || !maintenanceSettings.startTime ||
        !maintenanceSettings.endDate || !maintenanceSettings.endTime) {
      return 0;
    }

    const startDateTime = new Date(`${maintenanceSettings.startDate}T${maintenanceSettings.startTime}`);
    const endDateTime = new Date(`${maintenanceSettings.endDate}T${maintenanceSettings.endTime}`);
    const now = new Date();

    const totalDuration = endDateTime - startDateTime; // 총 점검 시간
    const elapsed = now - startDateTime; // 경과 시간

    if (totalDuration <= 0) return 0;

    // 진행률을 0%에서 100% 사이의 값으로 계산하여 반환합니다.
    const percentage = Math.min(Math.max((elapsed / totalDuration) * 100, 0), 100);
    return Math.round(percentage);
  };

  return (
    <div className={styles.maintenancePage}>
      <div className={styles.maintenanceContainer}>
        {/* 점검 아이콘과 반짝이는 효과 */}
        <div className={styles.iconContainer}>
          <div className={styles.maintenanceIcon}>🛠️</div>
          <div className={styles.sparkles}>
            <span>✨</span>
            <span>✨</span>
            <span>✨</span>
            <span>✨</span>
            <span>✨</span>
            <span>✨</span>
          </div>
        </div>

        {/* 페이지 주 제목 */}
        <h1 className={styles.mainTitle}>점검 안내</h1>

        {/* 점검 사유를 표시하는 뱃지 */}
        <div className={styles.reasonBadge}>
          {maintenanceSettings && maintenanceSettings.reason ? maintenanceSettings.reason : '점검 사유가 등록되어 있지 않습니다.'}
        </div>

        {/* 사용자에게 전달하는 주된 점검 메시지 */}
        <div className={styles.messageContainer}>
          <p className={styles.mainMessage}>
            {maintenanceSettings && maintenanceSettings.message ? maintenanceSettings.message : '서비스 점검이 진행 중입니다. 불편을 드려 죄송합니다. 잠시 후 다시 이용해 주세요.'}
          </p>
        </div>

        {/* 점검 진행률을 시각적으로 보여주는 프로그레스 바 */}
        <div className={styles.progressContainer}>
          <div className={styles.progressLabel}>진행률</div>
          <div className={styles.progressBar}>
            <div
              className={styles.progressFill}
              style={{ width: `${getProgressPercentage()}%` }}
            ></div>
          </div>
          <div className={styles.progressText}>{getProgressPercentage()}% 진행</div>
        </div>

        {/* 현재 시각, 종료 예정 시각, 남은 시간을 표시하는 카드 */}
        <div className={styles.timeInfo}>
          <div className={styles.timeCard}>
            <div className={styles.timeLabel}>현재 시각</div>
            <div className={styles.timeValue}>
              {currentTime.toLocaleString('ko-KR', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
              })}
            </div>
          </div>

          <div className={styles.timeCard}>
            <div className={styles.timeLabel}>종료 예정</div>
            <div className={styles.timeValue}>{formatEndTime()}</div>
          </div>

          {timeLeft && (
            <div className={styles.timeCard}>
              <div className={styles.timeLabel}>남은 시간</div>
              <div className={styles.countdownValue}>
                {timeLeft.hours > 0 && `${timeLeft.hours}시간 `}
                {timeLeft.minutes}분
              </div>
            </div>
          )}
        </div>

        {/* 점검 범위, 일정, 문의 등 추가 정보를 제공하는 카드 */}
        <div className={styles.infoContainer}>
          <div className={styles.infoCard}>
            <div className={styles.infoIcon}></div>
            <div className={styles.infoText}>
              <strong>점검 범위</strong>
              <p>점검 시간 동안 일부 서비스 기능 이용이 제한될 수 있습니다.</p>
            </div>
          </div>

          <div className={styles.infoCard}>
            <div className={styles.infoIcon}>🕒</div>
            <div className={styles.infoText}>
              <strong>점검 일정</strong>
              <p>예정된 시간에 점검이 진행됩니다. 이용에 참고해 주세요.</p>
            </div>
          </div>

          <div className={styles.infoCard}>
            <div className={styles.infoIcon}>📞</div>
            <div className={styles.infoText}>
              <strong>문의</strong>
              <p>긴급 문의는 고객센터로 연락 바랍니다.</p>
            </div>
          </div>
        </div>

        {/* 회사 로고 및 브랜드 메시지 */}
        <div className={styles.brandingContainer}>
          <div className={styles.logo}>PetCare</div>
          <p className={styles.brandText}>PetCare 서비스를 이용해 주셔서 감사합니다.</p>
        </div>
      </div>

      {/* 페이지 배경에 떠다니는 애니메이션 요소들 */}
      <div className={styles.backgroundAnimation}>
        <div className={styles.floatingElement} style={{ '--delay': '0s', '--duration': '20s' }}>⭐</div>
        <div className={styles.floatingElement} style={{ '--delay': '2s', '--duration': '25s' }}>✨</div>
        <div className={styles.floatingElement} style={{ '--delay': '4s', '--duration': '18s' }}>🛠️</div>
        <div className={styles.floatingElement} style={{ '--delay': '6s', '--duration': '22s' }}>⚙️</div>
        <div className={styles.floatingElement} style={{ '--delay': '8s', '--duration': '26s' }}>💤</div>
      </div>
    </div>
  );
};

export default MaintenancePage;