export { default as GroomingPage } from './GroomingPage';
export { default as HospitalPage } from './HospitalPage';
export { default as HotelPage } from './HotelPage';
export { default as CafePage } from './CafePage';


