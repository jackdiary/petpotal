import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import styles from './PostEditor.module.css';
import Button from '../components/ui/Button';

// --- CKEditor 5 Custom Upload Adapter ---
function CustomUploadAdapterPlugin(editor) {
  editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
    return new MyUploadAdapter(loader);
  };
}

const PostEditor = () => {
  const { boardKey, postId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const isEditing = !!postId;
  const [categories, setCategories] = useState([]);
  const [selectedBoardKey, setSelectedBoardKey] = useState(boardKey || 'free-talk');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [images, setImages] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editorInstance, setEditorInstance] = useState(null);
  const fileInputRef = useRef(null);
  
  useEffect(() => {
    fetchCategories();
    if (isEditing) {
      fetchPostData();
    }
  }, []);

  const fetchPostData = async () => {
    try {
      const response = await fetch(`http://localhost:3001/api/community/posts/${postId}`);
      const data = await response.json();
      if (data.success && data.data) {
        const post = data.data;
        setTitle(post.title);
        setContent(post.content);
        setSelectedBoardKey(post.boardKey);
        // TODO: 이미지 수정 기능 구현 시 기존 이미지 불러오기
      } else {
        alert('게시글 정보를 불러오는 데 실패했습니다.');
        navigate('/community');
      }
    } catch (error) {
      console.error('게시글 조회 오류:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      // Add a cache-busting parameter to force fresh data
      const response = await fetch(`http://localhost:3001/api/community/categories?_=${new Date().getTime()}`);
      const data = await response.json();

      if (data.success) {
        setCategories(data.data || []);
      }
    } catch (error) {
      console.error('카테고리 조회 오류:', error);
    }
  };

  const handleCancel = () => {
    if (title.trim() || content.trim() || images.length > 0) {
      if (window.confirm(`${isEditing ? '수정' : '작성'}을 취소하시겠습니까? 변경사항이 저장되지 않습니다.`)) {
        navigate(isEditing ? `/community/posts/${postId}` : '/community');
      }
    } else {
      navigate(isEditing ? `/community/posts/${postId}` : '/community');
    }
  };

  const handleSubmit = async () => {
    if (!user) {
      alert('로그인이 필요합니다.');
      navigate('/login');
      return;
    }

    if (!title.trim()) {
      alert('제목을 입력해주세요.');
      return;
    }

    if (!content.trim()) {
      alert('내용을 입력해주세요.');
      return;
    }

    setIsSubmitting(true);

    try {
      const postData = {
        boardKey: selectedBoardKey,
        title: title.trim(),
        content: content.trim()
      };

      const token = localStorage.getItem('authToken');
      console.log('토큰 상태:', token ? '있음' : '없음');
      console.log('사용자 상태:', user);
      console.log('전송할 데이터:', postData);

      if (!token) {
        alert('로그인 토큰이 없습니다. 다시 로그인해주세요.');
        navigate('/login');
        return;
      }

      const url = isEditing ? `http://localhost:3001/api/community/posts/${postId}` : 'http://localhost:3001/api/community/posts';
      const method = isEditing ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method: method,
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(postData)
      });

      // 응답 상태 코드 확인
      if (!response.ok) {
        if (response.status === 401) {
          alert('로그인이 필요합니다. 다시 로그인해주세요.');
          localStorage.removeItem('authToken');
          navigate('/login');
          return;
        } else if (response.status === 403) {
          alert('권한이 없습니다. 로그인 상태를 확인해주세요.');
          return;
        } else {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
      }

      const data = await response.json();

      if (data.success) {
        alert(`게시글이 ${isEditing ? '수정' : '등록'}되었습니다.`);
        navigate(isEditing ? `/community/posts/${postId}` : `/community/${selectedBoardKey}`);
      } else {
        alert(data.message || `게시글 ${isEditing ? '수정' : '등록'}에 실패했습니다.`);
      }
    } catch (error) {
      console.error(`게시글 ${isEditing ? '수정' : '등록'} 오류:`, error);
      alert(`게시글 ${isEditing ? '수정' : '등록'} 중 오류가 발생했습니다.`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) {
    return (
      <div className="container">
        <div className={styles.loginRequired}>
          <h2>로그인이 필요합니다</h2>
          <p>글쓰기를 하려면 먼저 로그인해주세요.</p>
          <Button variant="primary" onClick={() => navigate('/login')}>
            로그인하기
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className={styles.editorLayout}>
        <header className={styles.editorHeader}>
          <h2>{isEditing ? '글 수정' : '글쓰기'}</h2>
        </header>

        <div className={styles.formGroup}>
          <label className={styles.label}>게시판 선택</label>
          <select
            value={selectedBoardKey}
            onChange={(e) => setSelectedBoardKey(e.target.value)}
            className={styles.boardSelector}
            disabled={isEditing} // 수정 시 게시판 변경 불가
          >
            {categories.map((category) => (
              <option key={category.boardKey} value={category.boardKey}>
                {category.category_name}
              </option>
            ))}
          </select>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>제목</label>
          <input
            type="text"
            placeholder="제목을 입력하세요"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className={styles.titleInput}
            maxLength={200}
          />
          <div className={styles.charCount}>{title.length}/200</div>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>내용</label>
          <div className={styles.editorWrapper}>
            <CKEditor
              editor={ClassicEditor}
              data={content}
              config={{
                extraPlugins: [CustomUploadAdapterPlugin],
                placeholder: "내용을 입력하세요...",
                // 여기에 추가적인 CKEditor 설정을 할 수 있습니다.
                // 예: toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
              }}
              onReady={editor => {
                setEditorInstance(editor);
              }}
              onChange={(event, editor) => {
                const data = editor.getData();
                setContent(data);
              }}
            />
          </div>
        </div>

        {/* 기존 이미지 첨부 UI는 에디터에 통합되었으므로 제거합니다. */}

        <footer className={styles.editorFooter}>
          <Button
            variant="secondary"
            size="medium"
            onClick={handleCancel}
            disabled={isSubmitting}
          >
            취소
          </Button>
          <Button
            variant="primary"
            size="medium"
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? (isEditing ? '수정 중...' : '등록 중...') : (isEditing ? '수정' : '등록')}
          </Button>
        </footer>
      </div>
    </div>
  );
};

// --- CKEditor 5 Custom Upload Adapter Class ---
class MyUploadAdapter {
  constructor(loader) {
    this.loader = loader;
  }

  upload() {
    return this.loader.file.then(
      (file) =>
        new Promise((resolve, reject) => {
          const formData = new FormData();
          formData.append('image', file); // 'image'는 서버에서 받을 필드명

          // 서버의 이미지 업로드 API 엔드포인트
          const uploadUrl = 'http://localhost:3001/api/community/upload-image';
          const token = localStorage.getItem('authToken');

          fetch(uploadUrl, {
            method: 'POST',
            body: formData,
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          })
            .then((response) => {
              if (!response.ok) {
                return response.json().then(data => reject(data.message || '이미지 업로드 실패'));
              }
              return response.json();
            })
            .then((data) => {
              if (data.success && data.url) {
                resolve({
                  default: data.url, // 서버에서 반환된 이미지 URL
                });
              } else {
                reject(data.message || '서버에서 URL을 반환하지 않았습니다.');
              }
            })
            .catch((error) => {
              reject(error.message || '네트워크 오류 또는 서버 문제 발생');
            });
        })
    );
  }

  abort() {
    // 업로드 중단 로직 (필요 시 구현)
  }
}

export default PostEditor;