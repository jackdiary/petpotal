// src/pages/PetSuppliesPage.jsx
// 반려용품 목록을 표시하는 페이지 컴포넌트
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom'; // 페이지 이동과 URL 파라미터를 위한 훅
import styles from './PetSuppliesPage.module.css'; // 스타일 모듈 임포트
import petSuppliesData from '../data/petSupplies.json'; // 반려용품 데이터 임포트

const PetSuppliesPage = () => {
  const [products, setProducts] = useState([]); // 상품 목록 상태
  const [categories, setCategories] = useState([]); // 카테고리 목록 상태
  const [loading, setLoading] = useState(true); // 로딩 상태
  const [currentPage, setCurrentPage] = useState(1); // 현재 페이지 번호
  const [totalPages, setTotalPages] = useState(1); // 전체 페이지 수
  const [selectedCategory, setSelectedCategory] = useState(''); // 선택된 카테고리
  const [searchTerm, setSearchTerm] = useState(''); // 검색어
  const navigate = useNavigate(); // 페이지 이동을 위한 훅
  const { category } = useParams(); // URL 파라미터에서 카테고리 추출

  // 페이지, 카테고리, 검색어 변경 시 상품 목록 업데이트
  useEffect(() => {
    fetchCategories(); // 카테고리 목록 가져오기
    fetchProducts(); // 상품 목록 가져오기
  }, [currentPage, selectedCategory, searchTerm, category]);

  // URL 파라미터의 카테고리가 변경될 때 선택된 카테고리 업데이트
  useEffect(() => {
    if (category) {
      setSelectedCategory(category);
    }
  }, [category]);

  // 카테고리 목록을 가져오는 함수 (프론트엔드 전용)
  const fetchCategories = async () => {
    try {
      // 백엔드 API 호출 대신 로컬 데이터에서 카테고리 추출
      // const response = await fetch('http://localhost:3001/api/pet-supplies/categories');
      // const data = await response.json();
      
      // JSON 데이터에서 고유한 카테고리 목록 추출
      const uniqueCategories = [...new Set(petSuppliesData.map(product => product.category))];
      setCategories(uniqueCategories); // 카테고리 목록 상태 업데이트
    } catch (error) {
      console.error('카테고리 조회 실패:', error); // 오류 로그 출력
    }
  };

  // 상품 목록을 가져오는 함수 (프론트엔드 전용)
  const fetchProducts = async () => {
    try {
      setLoading(true); // 로딩 시작
      
      // 백엔드 API 호출 대신 로컬 데이터 필터링
      let filteredProducts = [...petSuppliesData];
      
      // 카테고리 필터링
      if (selectedCategory || category) {
        filteredProducts = filteredProducts.filter(product => 
          product.category === (selectedCategory || category)
        );
      }
      
      // 검색어 필터링
      if (searchTerm) {
        filteredProducts = filteredProducts.filter(product =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.description.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }
      
      // 페이지네이션 처리
      const itemsPerPage = 12; // 페이지당 상품 수
      const totalItems = filteredProducts.length; // 전체 상품 수
      const calculatedTotalPages = Math.ceil(totalItems / itemsPerPage); // 전체 페이지 수 계산
      const startIndex = (currentPage - 1) * itemsPerPage; // 시작 인덱스
      const endIndex = startIndex + itemsPerPage; // 끝 인덱스
      const paginatedProducts = filteredProducts.slice(startIndex, endIndex); // 페이지별 상품 추출
      
      setProducts(paginatedProducts); // 상품 목록 상태 업데이트
      setTotalPages(calculatedTotalPages); // 전체 페이지 수 상태 업데이트
    } catch (error) {
      console.error('상품 조회 실패:', error); // 오류 로그 출력
    } finally {
      setLoading(false); // 로딩 종료
    }
  };

  // 카테고리 변경 처리 함수
  const handleCategoryChange = (categoryName) => {
    setSelectedCategory(categoryName); // 선택된 카테고리 상태 업데이트
    setCurrentPage(1); // 페이지를 첫 번째로 리셋
    navigate(categoryName ? `/pet-supplies/category/${categoryName}` : '/pet-supplies'); // URL 변경
  };

  // 검색 폼 제출 처리 함수
  const handleSearch = (e) => {
    e.preventDefault(); // 기본 폼 제출 동작 방지
    setCurrentPage(1); // 페이지를 첫 번째로 리셋
    fetchProducts(); // 상품 목록 다시 가져오기
  };

  // 상품 클릭 시 상세 페이지로 이동하는 함수
  const handleProductClick = (productId) => {
    navigate(`/pet-supplies/${productId}`); // 상품 상세 페이지로 이동
  };

  // 가격을 한국 원화 형식으로 포맷팅하는 함수
  const formatPrice = (price) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency', // 통화 스타일 적용
      currency: 'KRW' // 한국 원화 설정
    }).format(price);
  };

  // 페이지 변경 처리 함수
  const handlePageChange = (page) => {
    setCurrentPage(page); // 현재 페이지 상태 업데이트
    window.scrollTo(0, 0); // 페이지 상단으로 스크롤
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>반려용품</h1>
        <p className={styles.subtitle}>우리 아이를 위한 특별한 용품들을 만나보세요</p>
      </div>

      {/* 검색 및 필터 */}
      <div className={styles.filterSection}>
        <form onSubmit={handleSearch} className={styles.searchForm}>
          <input
            type="text"
            placeholder="상품명을 검색하세요..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={styles.searchInput}
          />
          <button type="submit" className={styles.searchButton}>
            검색
          </button>
        </form>

        <div className={styles.categoryFilter}>
          <button
            className={`${styles.categoryButton} ${!selectedCategory ? styles.active : ''}`}
            onClick={() => handleCategoryChange('')}
          >
            전체
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              className={`${styles.categoryButton} ${selectedCategory === cat ? styles.active : ''}`}
              onClick={() => handleCategoryChange(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 상품 목록 */}
      {loading ? (
        <div className={styles.loading}>상품을 불러오는 중...</div>
      ) : (
        <>
          <div className={styles.productsGrid}>
            {products.length > 0 ? (
              products.map((product) => (
                <div
                  key={product.id}
                  className={styles.productCard}
                  onClick={() => handleProductClick(product.id)}
                >
                  <div className={styles.imageWrapper}>
                    <img
                      src={product.imageUrl || 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400'}
                      alt={product.name}
                      className={styles.productImage}
                    />
                    {product.isBest && (
                      <span className={styles.bestBadge}>BEST</span>
                    )}
                    {product.isFeatured && (
                      <span className={styles.featuredBadge}>추천</span>
                    )}
                  </div>
                  <div className={styles.productInfo}>
                    <div className={styles.category}>{product.category}</div>
                    <h3 className={styles.productName}>{product.name}</h3>
                    <p className={styles.productDescription}>{product.description}</p>
                    <div className={styles.productMeta}>
                      <span className={styles.price}>{formatPrice(product.price)}</span>
                      {product.rating > 0 && (
                        <div className={styles.rating}>
                          <span className={styles.stars}>⭐</span>
                          <span className={styles.ratingText}>{product.rating}</span>
                        </div>
                      )}
                    </div>
                    {product.brand && (
                      <div className={styles.brand}>{product.brand}</div>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className={styles.noProducts}>
                <p>검색 결과가 없습니다.</p>
              </div>
            )}
          </div>

          {/* 페이지네이션 */}
          {totalPages > 1 && (
            <div className={styles.pagination}>
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className={styles.pageButton}
              >
                이전
              </button>
              
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => handlePageChange(page)}
                  className={`${styles.pageButton} ${currentPage === page ? styles.active : ''}`}
                >
                  {page}
                </button>
              ))}
              
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className={styles.pageButton}
              >
                다음
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default PetSuppliesPage;