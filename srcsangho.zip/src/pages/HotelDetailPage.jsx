import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import styles from './GroomingDetailPage.module.css'; // 스타일 재사용
import Button from '../components/Button';
import { useUI } from '../contexts/UIContext';
import { mockDataService } from '../utils/mockDataService';

const HotelDetailPage = () => {
  const { hotelId } = useParams();
  const navigate = useNavigate();
  const { setIsLoading } = useUI() || {};
  const [hotel, setHotel] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchHotelDetails = async () => {
      if (setIsLoading) setIsLoading(true);
      setError(null);
      try {
        const response = await mockDataService.getById('hotel', parseInt(hotelId, 10));
        if (response.success) {
          setHotel(response.data);
        } else {
          setError(response.message || '호텔 정보를 불러오는 데 실패했습니다.');
        }
      } catch (err) {
        console.error('Failed to fetch hotel details:', err);
        setError('호텔 정보를 불러오는 데 실패했습니다.');
      } finally {
        if (setIsLoading) setIsLoading(false);
      }
    };

    if (hotelId) {
      fetchHotelDetails();
    }
  }, [hotelId, setIsLoading]);

  if (!hotel && !error) {
    return <div className="container">호텔 정보를 불러오는 중...</div>;
  }

  if (error) {
    return (
      <div className="container">
        <div className={styles.notFound}>
          <h2>{error}</h2>
          <Link to="/hotel">
            <Button variant="primary">호텔 목록으로 돌아가기</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.detailPageContainer}>
      <section className={styles.carouselSection}>
        <Carousel showThumbs={false} infiniteLoop autoPlay showStatus={false}>
          {(hotel.images && hotel.images.length > 0 ? hotel.images : [hotel.image]).map((img, index) => (
            <div key={index}>
              <img src={img} alt={`${hotel.name} 이미지 ${index + 1}`} />
            </div>
          ))}
        </Carousel>
        <div className={styles.heroContent}>
          <h1>{hotel.name}</h1>
          <p className={styles.shopLocation}>{hotel.address}</p>
        </div>
      </section>

      <main className={styles.mainContent}>
        <div className={styles.infoColumn}>
          <div className={styles.infoBlock}>
            <h3>운영 정보</h3>
            <ul className={styles.infoList}>
              <li><strong>운영 시간:</strong> {hotel.operatingHours?.start} - {hotel.operatingHours?.end}</li>
              <li><strong>연락처:</strong> {hotel.phone || '정보 없음'}</li>
              <li><strong>1박 가격:</strong> {hotel.pricePerNight?.toLocaleString()}원 ~</li>
            </ul>
          </div>

          <div className={styles.infoBlock}>
            <h3>주요 서비스</h3>
            <div className={styles.tags}>
              {(hotel.services || []).map((service, index) => (
                <span key={index} className={styles.tag}>{service}</span>
              ))}
            </div>
          </div>
        </div>

        <aside className={styles.reviewColumn}>
          <div className={styles.infoBlock}>
            <h3>리뷰 및 평점</h3>
            <div className={styles.reviewList}>
              <p>⭐ {hotel.rating} / 5.0 ({hotel.reviews}개 리뷰)</p>
              <p>리뷰 상세 기능은 준비 중입니다.</p>
            </div>
            <div className={styles.actionButtons}>
              <Button variant="primary" size="large" onClick={() => alert('예약 기능은 준비 중입니다.')}>
                예약하기
              </Button>
              <Button variant="secondary" size="large" onClick={() => window.open(`tel:${hotel.phone}`)}>
                전화 문의
              </Button>
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
};

export default HotelDetailPage;