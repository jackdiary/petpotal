import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import styles from './GroomingDetailPage.module.css'; // 스타일 재사용
import Button from '../components/Button';
import { useUI } from '../contexts/UIContext';
import { mockDataService } from '../utils/mockDataService';

const HospitalDetailPage = () => {
  const { hospitalId } = useParams();
  const navigate = useNavigate();
  const { setIsLoading } = useUI() || {};
  const [hospital, setHospital] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchHospitalDetails = async () => {
      if (setIsLoading) setIsLoading(true);
      setError(null);
      try {
        const response = await mockDataService.getById('hospital', parseInt(hospitalId, 10));
        if (response.success) {
          setHospital(response.data);
        } else {
          setError(response.message || '병원 정보를 불러오는 데 실패했습니다.');
        }
      } catch (err) {
        console.error('Failed to fetch hospital details:', err);
        setError('병원 정보를 불러오는 데 실패했습니다.');
      } finally {
        if (setIsLoading) setIsLoading(false);
      }
    };

    if (hospitalId) {
      fetchHospitalDetails();
    }
  }, [hospitalId, setIsLoading]);

  if (!hospital && !error) {
    return <div className="container">병원 정보를 불러오는 중...</div>;
  }

  if (error) {
    return (
      <div className="container">
        <div className={styles.notFound}>
          <h2>{error}</h2>
          <Link to="/hospital">
            <Button variant="primary">병원 목록으로 돌아가기</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.detailPageContainer}>
      <section className={styles.carouselSection}>
        <Carousel showThumbs={false} infiniteLoop autoPlay showStatus={false}>
          {(hospital.images && hospital.images.length > 0 ? hospital.images : [hospital.image]).map((img, index) => (
            <div key={index}>
              <img src={img} alt={`${hospital.name} 이미지 ${index + 1}`} />
            </div>
          ))}
        </Carousel>
        <div className={styles.heroContent}>
          <h1>{hospital.name}</h1>
          <p className={styles.shopLocation}>{hospital.address}</p>
        </div>
      </section>

      <main className={styles.mainContent}>
        <div className={styles.infoColumn}>
          <div className={styles.infoBlock}>
            <h3>운영 정보</h3>
            <ul className={styles.infoList}>
              <li><strong>운영 시간:</strong> {hospital.hours || '정보 없음'}</li>
              <li><strong>연락처:</strong> {hospital.phone || '정보 없음'}</li>
              <li><strong>주소:</strong> {hospital.address}</li>
            </ul>
          </div>

          <div className={styles.infoBlock}>
            <h3>진료 과목</h3>
            <div className={styles.tags}>
              {(hospital.services || []).map((service, index) => (
                <span key={index} className={styles.tag}>{service}</span>
              ))}
            </div>
          </div>
        </div>

        <aside className={styles.reviewColumn}>
          <div className={styles.infoBlock}>
            <h3>리뷰 및 평점</h3>
            <div className={styles.reviewList}>
              <p>⭐ {hospital.rating} / 5.0</p>
              <p>리뷰 기능은 준비 중입니다.</p>
            </div>
            <div className={styles.actionButtons}>
              <Button variant="primary" size="large" onClick={() => alert('예약 기능은 준비 중입니다.')}>
                진료 예약
              </Button>
              <Button variant="secondary" size="large" onClick={() => window.open(`tel:${hospital.phone}`)}>
                전화 문의
              </Button>
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
};

export default HospitalDetailPage;