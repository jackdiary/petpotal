import React, { useEffect, useMemo, useState, useCallback } from 'react';
import HospitalMapView from '../components/service/maps/HospitalMapView';
import BusinessCardGrid from '../components/common/BusinessCardGrid';
import FilterSection from '../components/common/FilterSection';
import '../styles/hospital.css';
import mapStyles from './MapPage.module.css'; // 지도 스타일 import
import useFetchAndFilterData from '../hooks/useFetchAndFilterData';
import hospitalData from '../data/hospital.json'; // 로컬 데이터 import
import Pagination from '../components/common/Pagination';

// const API_URL = 'http://localhost:3001/api/hospital'; // 로컬 데이터 사용으로 변경

const HospitalPage = () => {
  const [userLocation, setUserLocation] = useState(null);
  const [filters, setFilters] = useState({
    location: '',
    appointment: '',
    hospitalServices: [],
    targetAnimals: []
  });

  const filterHospitals = useCallback((dataToFilter) => {
    let hospitals = dataToFilter;
    if (filters.location) { // 위치 필터
        hospitals = hospitals.filter(hospital => 
            hospital.name.toLowerCase().includes(filters.location.toLowerCase()) ||
            hospital.address.toLowerCase().includes(filters.location.toLowerCase()));
    }
    if (filters.hospitalServices.length > 0) {
        hospitals = hospitals.filter(hospital => filters.hospitalServices.every(service => (hospital.services || []).includes(service)));
    }
    if (filters.targetAnimals.length > 0) {
        hospitals = hospitals.filter(hospital => filters.targetAnimals.every(animal => (hospital.targetAnimals || []).includes(animal)));
    }
    return hospitals;
  }, [filters]);

  const {
    filteredData: hospitals,
    allData: allHospitals,
    applyFilter,
    loading,
    error,
    currentPage,
    totalPages,
    totalItems,
    goToPage,
    searchTerm,
    updateSearchTerm
  } = useFetchAndFilterData(hospitalData, (data) => data || [], { // 데이터 소스를 hospitalData로 변경
    enablePagination: true,
    enableSearch: true,
    itemsPerPage: 6
  });

  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => setUserLocation({ lat: 37.5665, lng: 126.9780 })
    );
  }, []);

  useEffect(() => {
    applyFilter(filterHospitals);
  }, [filters, allHospitals, applyFilter, filterHospitals]);

  const markers = useMemo(() => allHospitals.map(hospital => ({
    id: hospital.id,
    lat: hospital.lat,
    lng: hospital.lng,
    name: hospital.name,
    // Add hospital-specific data
    specialties: hospital.services || ['general'],
    isEmergency: hospital.services?.includes('24시 응급') || false,
    is24Hours: hospital.services?.includes('24시 응급') || false,
    phone: hospital.phone || '',
    emergencyPhone: hospital.emergencyPhone || hospital.phone || '',
    rating: hospital.rating || 4.0,
    address: hospital.address || ''
  })), [allHospitals]);

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  const handleToggleFilter = (filterType, value) => {
    setFilters((prev) => {
      const currentValues = prev[filterType];
      const newValues = currentValues.includes(value)
        ? currentValues.filter((v) => v !== value)
        : [...currentValues, value];
      return { ...prev, [filterType]: newValues };
    });
  };

  if (loading) {
    return <div className="pageContainer">병원 정보를 불러오는 중...</div>;
  }

  if (error) {
    return <div className="pageContainer" style={{ color: 'red' }}>오류: {error.message || '데이터를 불러오는 중 오류가 발생했습니다.'}</div>;
  }

  return (
    <div className="hospital-container">
      <header className="hospital-header">
        <h1 className="hospital-title">동물병원</h1>
        <p className="hospital-subtitle">우리 아이를 맡길 수 있는 믿을 만한 동물병원을 찾아보세요</p>
      </header>

      <div className={mapStyles.mapWrapper}>
        <HospitalMapView 
          userLocation={userLocation} 
          markers={markers}
          filters={{
            specialties: filters.hospitalServices,
            emergencyOnly: filters.hospitalServices.includes('24시 응급'),
            available24h: filters.hospitalServices.includes('24시 응급')
          }}
          onMarkerClick={(markerData) => {
            console.log('Hospital marker clicked:', markerData);
            // Could show detailed popup or navigate to detail page
          }}
        />
        <div className="filtersOnMap">
          <FilterSection
            locationPlaceholder="병원이름이나 지역을 검색해보세요"
            onLocationChange={(value) => handleFilterChange('location', value)}
          >
            <div className="filterGroup">
              <label className="filterLabel">진료 종류</label>
              <div className="pillButtonContainer">
                {['24시 응급', '내과', '외과', '치과', '심장 전문', 'MRI/CT'].map(type => (
                  <button key={type} onClick={() => handleToggleFilter('hospitalServices', type)} className={`hospital-filter-btn ${filters.hospitalServices.includes(type) ? 'active' : ''}`}>
                    {type}
                  </button>
                ))}
              </div>
            </div>
            <div className="filterGroup">
              <label className="filterLabel">대상 동물</label>
              <div className="pillButtonContainer">
                {['강아지', '고양이', '특수동물'].map(animal => (
                  <button key={animal} onClick={() => handleToggleFilter('targetAnimals', animal)} className={`hospital-filter-btn ${filters.targetAnimals.includes(animal) ? 'active' : ''}`}>
                    {animal}
                  </button>
                ))}
              </div>
            </div>
          </FilterSection>
        </div>
      </div>

      <div className="hospital-grid">
        <BusinessCardGrid items={hospitals} itemType="hospital" />
      </div>

      {hospitals.length > 0 && totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={goToPage}
        />
      )}
    </div>
  );
};

export default HospitalPage;
