// React 및 관련 훅들을 가져옵니다.
import React, { useEffect, useMemo, useState, useCallback } from 'react';
// 지도, 카드 그리드, 필터 섹션 등 UI 컴포넌트들을 가져옵니다.
import MapView from '../components/common/MapView';
import GroomingCardGrid from '../components/grooming/GroomingCardGrid';
import FilterSection from '../components/common/FilterSection';
import Pagination from '../components/common/Pagination'; // Pagination 컴포넌트 import
// 공통 페이지 및 지도 관련 스타일을 가져옵니다.
import pageStyles from './Page.module.css';
import mapStyles from './MapPage.module.css';
// 데이터 fetching 및 필터링을 위한 커스텀 훅을 가져옵니다.
import useFetchAndFilterData from '../hooks/useFetchAndFilterData';
// 위치 관련 유틸리티 함수를 가져옵니다.
import { getDistance } from '../utils/locationUtils';
// 로컬 미용 서비스 데이터를 가져옵니다.
import groomingData from '../data/grooming.json'; // 이 데이터를 직접 사용합니다.

// API URL은 현재 사용하지 않으므로 주석 처리하거나 제거합니다.
// const API_URL = 'http://localhost:3001/api/grooming';

// GroomingPage 컴포넌트 정의
const GroomingPage = () => {
  // 사용자 위치, 필터 상태를 관리하는 state입니다.
  const [userLocation, setUserLocation] = useState(null); // 사용자 현재 위치
  // const [mapCenter, setMapCenter] = useState(null); // 지도 중심 좌표 (현재 사용되지 않음)
  // 필터링 조건들을 관리하는 state입니다.
  const [filters, setFilters] = useState({
    location: '',
    groomingTypes: [],
    targetAnimals: []
  });

  // 미용실 데이터를 필터링하는 콜백 함수입니다.
  const filterGroomings = useCallback((dataToFilter) => {
    let groomings = dataToFilter; // 전체 미용실 데이터로부터 필터링 시작

    // 위치(이름 또는 주소)로 필터링합니다. (로직 최적화)
    if (filters.location) {
      const locationQuery = filters.location.toLowerCase();
      groomings = groomings.filter(grooming => grooming.name.toLowerCase().includes(locationQuery) || grooming.address.toLowerCase().includes(locationQuery));
    }
    // 선택된 미용 종류로 필터링합니다.
    if (filters.groomingTypes.length > 0) {
        groomings = groomings.filter(grooming => filters.groomingTypes.some(type => (grooming.services || []).includes(type)));
    }
    // 선택된 대상 동물로 필터링합니다.
    if (filters.targetAnimals.length > 0) {
        groomings = groomings.filter(grooming => filters.targetAnimals.some(animal => (grooming.services || []).includes(animal)));
    }
    // 사용자 위치 기준 거리 필터링 (5km 이내)
    if (userLocation && groomings.length > 0) { // groomings가 비어있지 않을 때만 거리 계산
        groomings = groomings.filter(grooming => {
            // grooming.latitude와 grooming.longitude가 유효한 숫자인지 확인
            if (typeof grooming.latitude === 'number' && typeof grooming.longitude === 'number') {
                const distance = getDistance(userLocation.lat, userLocation.lng, grooming.latitude, grooming.longitude);
                return distance <= 5; // 5km 이내 필터링
            }
            return false; // 유효하지 않은 좌표는 필터링
        });
    }
    return groomings; // 필터링된 결과를 반환합니다.
  }, [filters]);

  // 커스텀 훅을 사용하여 미용실 데이터를 가져오고 필터링을 적용합니다.
  const { 
    filteredData: groomings, 
    allData: allGroomings, 
    applyFilter, loading, error,
    currentPage, totalPages, goToPage 
  } = useFetchAndFilterData(
    groomingData, // 데이터 소스를 API URL 대신 grooming.json으로 변경
    (data) => data || [], 
    { enablePagination: true, itemsPerPage: 6 }
  );

  // 컴포넌트 마운트 시 사용자의 현재 위치를 가져옵니다. (현재는 주석 처리됨)
  useEffect(() => {
    // navigator.geolocation이 지원되면 사용자의 현재 위치를 가져옵니다.
    navigator.geolocation?.getCurrentPosition(
      (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      // 위치 정보 가져오기 실패 시 기본 위치(서울 시청)로 설정합니다.
      () => setUserLocation({ lat: 37.5665, lng: 126.9780 })
    );
  }, []);

  // 필터나 전체 데이터가 변경될 때마다 필터링 함수를 다시 적용합니다.
  useEffect(() => {
    applyFilter(filterGroomings);
  }, [filters, allGroomings, applyFilter, filterGroomings]);

  // 필터링된 미용실 데이터를 기반으로 지도에 표시할 마커를 생성합니다.
  const markers = useMemo(() => groomings.map(({ id, latitude, longitude, name }) => ({ id, lat: latitude, lng: longitude, name })), [groomings]);

  // 일반적인 필터 값 변경을 처리하는 핸들러입니다. (예: 텍스트 입력, 날짜 선택)
  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  // 체크박스와 같이 여러 값을 가질 수 있는 필터의 값 토글을 처리하는 핸들러입니다.
  const handleToggleFilter = (filterType, value) => {
    setFilters((prev) => {
      const currentValues = prev[filterType];
      // 이미 선택된 값이면 제거하고, 아니면 추가합니다.
      const newValues = currentValues.includes(value)
        ? currentValues.filter((v) => v !== value)
        : [...currentValues, value];
      return { ...prev, [filterType]: newValues };
    });
  };

  // 데이터 로딩 중일 때 표시할 UI입니다.
  if (loading) {
    return <div className={pageStyles.pageContainer}>미용 정보를 불러오는 중...</div>;
  }

  // 데이터 로딩 중 오류 발생 시 표시할 UI입니다.
  if (error) {
    return <div className={pageStyles.pageContainer} style={{ color: 'red' }}>오류: {error.message || '데이터를 불러오는 중 오류가 발생했습니다.'}</div>;
  }

  return (
    <div className={pageStyles.pageContainer}>
      <header className={pageStyles.pageHeader}>
        {/* 페이지 제목과 부제목 */}
        <h1 className={pageStyles.pageTitle}>펫 미용</h1>
        <p className={pageStyles.pageSubtitle}>전문 그루머가 제공하는 최고의 반려동물 미용 서비스</p>
      </header>

      <div className={mapStyles.mapWrapper}>
        <div className={mapStyles.filterPanel}>
          {/* 필터 섹션 컴포넌트 */}
          <FilterSection
            locationPlaceholder="미용실명이나 지역을 검색해보세요"
            onLocationChange={(value) => handleFilterChange('location', value)}
          >
            {/* 미용 종류 선택 필터 (체크박스) */}
            <div className={mapStyles.filterGroup}>
              <label className={mapStyles.filterLabel}>미용 종류</label>
              <div className={mapStyles.checkboxContainer}>
                {['목욕', '부분미용', '전체미용', '스타일링', '스파', '마사지', '무마취 미용', '고양이전문', '네일케어'].map(type => (
                  <label key={type} className={mapStyles.checkboxLabel}>
                    <input type="checkbox" value={type}
                      checked={filters.groomingTypes.includes(type)}
                      onChange={() => handleToggleFilter('groomingTypes', type)}
                      className={mapStyles.checkboxInput}
                    />
                    {type}
                  </label>
                ))}
              </div>
            </div>
            {/* 대상 동물 선택 필터 (체크박스) */}
            <div className={mapStyles.filterGroup}>
              <label className={mapStyles.filterLabel}>대상 동물</label>
              <div className={mapStyles.checkboxContainer}>
                {['강아지', '고양이', '특수동물'].map(animal => (
                  <label key={animal} className={mapStyles.checkboxLabel}>
                    <input type="checkbox" value={animal}
                      checked={filters.targetAnimals.includes(animal)}
                      onChange={() => handleToggleFilter('targetAnimals', animal)}
                      className={mapStyles.checkboxInput}
                    />
                    {animal}
                  </label>
                ))}
              </div>
            </div>
          </FilterSection>
        </div>
        {/* 지도 컨테이너 */}
        <div className={mapStyles.mapContainer}>
          <MapView userLocation={userLocation} markers={markers} />
        </div>
      </div>

      {/* 필터링된 미용실 목록을 카드로 표시하는 그리드 */}
      <GroomingCardGrid items={groomings} />

      {/* 페이지네이션 컨트롤 */}
      {totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={goToPage}
        />
      )}
    </div>
  );
};

export default GroomingPage;