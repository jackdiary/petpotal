import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import styles from './GroomingDetailPage.module.css';
import Button from '../components/Button';
import { useUI } from '../contexts/UIContext';
import { mockDataService } from '../utils/mockDataService';

const GroomingDetailPage = () => {
  const { groomingId } = useParams();
  const { setIsLoading } = useUI() || {};
  const [shop, setShop] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchShopDetails = async () => {
      if (setIsLoading) setIsLoading(true);
      setError(null);
      try {
        const response = await mockDataService.getById('grooming', parseInt(groomingId, 10));
        if (response.success) {
          setShop(response.data);
        } else {
          setError(response.message || '미용실 정보를 불러오는 데 실패했습니다.');
        }
      } catch (err) {
        console.error('Failed to fetch grooming shop details:', err);
        setError('미용실 정보를 불러오는 데 실패했습니다.');
      } finally {
        if (setIsLoading) setIsLoading(false);
      }
    };

    if (groomingId) {
      fetchShopDetails();
    }
  }, [groomingId, setIsLoading]);

  if (!shop && !error) {
    return <div className="container">미용실 정보를 불러오는 중...</div>;
  }

  if (error) {
    return (
      <div className="container">
        <div className={styles.notFound}>
          <h2>{error}</h2>
          <Link to="/grooming">
            <Button variant="primary">미용실 목록으로 돌아가기</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.detailPageContainer}>
      <section className={styles.carouselSection}>
        <Carousel showThumbs={false} infiniteLoop autoPlay showStatus={false}>
          {(shop.images && shop.images.length > 0 ? shop.images : [shop.image]).map((img, index) => (
            <div key={index}>
              <img src={img} alt={`${shop.name} 이미지 ${index + 1}`} />
            </div>
          ))}
        </Carousel>
        <div className={styles.heroContent}>
          <h1>{shop.name}</h1>
          <p className={styles.shopLocation}>{shop.address}</p>
        </div>
      </section>

      <main className={styles.mainContent}>
        <div className={styles.infoColumn}>
          <div className={styles.infoBlock}>
            <h3>운영 정보</h3>
            <ul className={styles.infoList}>
              <li><strong>운영 시간:</strong> {shop.operatingHours?.start || '09:00'} - {shop.operatingHours?.end || '18:00'}</li>
              <li><strong>연락처:</strong> {shop.phone || '정보 없음'}</li>
              <li><strong>주소:</strong> {shop.address}</li>
            </ul>
          </div>

          <div className={styles.infoBlock}>
            <h3>상세 가격표</h3>
            <table className={styles.priceTable}>
              <thead>
                <tr>
                  <th>서비스</th>
                  <th>소형견</th>
                  <th>중형견</th>
                  <th>대형견</th>
                </tr>
              </thead>
              <tbody>
                {(shop.priceList || []).map((item, index) => (
                  <tr key={index}>
                    <td>{item.service}</td>
                    <td>{item.small?.toLocaleString() || '-'}</td>
                    <td>{item.medium?.toLocaleString() || '-'}</td>
                    <td>{item.large?.toLocaleString() || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <aside className={styles.reviewColumn}>
          <div className={styles.infoBlock}>
            <h3>이용자 리뷰 ({shop.reviews?.length || 0}개)</h3>
            <div className={styles.reviewList}>
              {(shop.reviews && shop.reviews.length > 0) ? (
                shop.reviews.map(review => (
                  <div key={review.id} className={styles.reviewItem}>
                    <div className={styles.reviewHeader}>
                      <span className={styles.reviewAuthor}>{review.author}</span>
                      <span className={styles.reviewRating}>{'⭐'.repeat(review.rating)}</span>
                    </div>
                    <p className={styles.reviewContent}>{review.content}</p>
                  </div>
                ))
              ) : (
                <p>아직 작성된 리뷰가 없습니다.</p>
              )}
            </div>
            <div className={styles.actionButtons}>
              <Button variant="primary" size="large">예약하기</Button>
              <Button variant="secondary" size="large">전화 문의</Button>
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
};

export default GroomingDetailPage;