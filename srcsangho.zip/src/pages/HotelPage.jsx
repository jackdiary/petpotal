// src/pages/HotelPage.jsx
import React, { useEffect, useMemo, useState, useCallback } from 'react';
import HotelMapView from '../components/service/maps/HotelMapView';
import BusinessCardGrid from '../components/common/BusinessCardGrid';
import FilterSection from '../components/common/FilterSection';
import '../styles/hotel.css';
import mapStyles from './MapPage.module.css'; // 지도 스타일 import
import useFetchAndFilterData from '../hooks/useFetchAndFilterData';
import hotelData from '../data/hotel.json'; // 로컬 데이터 import
import Pagination from '../components/common/Pagination';

// const API_URL = 'http://localhost:3001/api/hotel'; // 로컬 데이터 사용으로 변경

const HotelPage = () => {
  const [userLocation, setUserLocation] = useState(null);
  const [filters, setFilters] = useState({
    location: '',
    startDate: '',
    endDate: '',
    priceRange: { min: 0, max: 100000 },
    hotelServices: [],
    targetAnimals: []
  });

  const filterHotels = useCallback((dataToFilter) => {
    let hotels = dataToFilter; // Filter from allHotels
    if (filters.location && !hotels.some(hotel => 
        hotel.name.toLowerCase().includes(filters.location.toLowerCase()) ||
        hotel.address.toLowerCase().includes(filters.location.toLowerCase()))
    ) {
        hotels = [];
    } else if (filters.location) {
        hotels = hotels.filter(hotel => 
            hotel.name.toLowerCase().includes(filters.location.toLowerCase()) ||
            hotel.address.toLowerCase().includes(filters.location.toLowerCase())
        );
    }
    hotels = hotels.filter(hotel => (hotel.pricePerNight ?? 0) >= filters.priceRange.min && (hotel.pricePerNight ?? 0) <= filters.priceRange.max);
    if (filters.hotelServices.length > 0) {
        hotels = hotels.filter(hotel => filters.hotelServices.every(service => (hotel.services || []).includes(service)));
    }
    if (filters.targetAnimals.length > 0) {
        hotels = hotels.filter(hotel => filters.targetAnimals.every(animal => (hotel.targetAnimals || []).includes(animal)));
    }
    return hotels;
  }, [filters]);

  const {
    filteredData: hotels,
    allData: allHotels,
    applyFilter,
    loading,
    error,
    currentPage,
    totalPages,
    totalItems,
    goToPage,
    searchTerm,
    updateSearchTerm
  } = useFetchAndFilterData(hotelData, (data) => data || [], { // 데이터 소스를 hotelData로 변경
    enablePagination: true,
    enableSearch: true,
    itemsPerPage: 6
  });

  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => setUserLocation({ lat: 37.5665, lng: 126.9780 })
    );
  }, []);

  useEffect(() => {
    applyFilter(filterHotels);
  }, [filters, allHotels, applyFilter, filterHotels]);

  const markers = useMemo(() => allHotels.map(hotel => ({
    id: hotel.id,
    lat: hotel.lat,
    lng: hotel.lng,
    name: hotel.name,
    // Add hotel-specific data
    petPolicy: {
      allowed: hotel.petFriendly || false,
      fee: hotel.petFee || 0,
      restrictions: hotel.petRestrictions || []
    },
    petAmenities: hotel.services?.filter(service => 
      ['pet-beds', 'pet-food', 'pet-sitting', 'pet-park', 'pet-spa'].includes(service)
    ) || [],
    roomTypes: hotel.roomTypes || ['standard'],
    priceRange: hotel.pricePerNight > 200000 ? 'luxury' : 
                hotel.pricePerNight > 100000 ? 'mid-range' : 'budget',
    rating: hotel.rating || 4.0,
    phone: hotel.phone || '',
    address: hotel.address || ''
  })), [allHotels]);

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  const handleToggleFilter = (filterType, value) => {
    setFilters((prev) => {
      const currentValues = prev[filterType];
      const newValues = currentValues.includes(value) ? currentValues.filter((v) => v !== value) : [...currentValues, value];
      return { ...prev, [filterType]: newValues };
    });
  };

  return (
    <div className="hotel-container">
      <header className="pageHeader">
        <h1 className="pageTitle">펫 호텔</h1>
        <p className="pageSubtitle">반려동물과 편안하게 머무를 수 있는 호텔을 찾아보세요</p>
      </header>
      <div className={mapStyles.mapWrapper}>
        <HotelMapView 
          userLocation={userLocation} 
          markers={markers}
          filters={{
            petFriendly: filters.targetAnimals.length > 0,
            petAmenities: filters.hotelServices,
            priceRanges: []
          }}
          onMarkerClick={(markerData) => {
            console.log('Hotel marker clicked:', markerData);
            // Could show detailed popup or navigate to detail page
          }}
        />
        <div className={mapStyles.filtersOnMap}>
          <FilterSection
            locationPlaceholder="호텔명이나 지역을 검색해보세요"
            onLocationChange={(value) => handleFilterChange('location', value)}>
            <div className={mapStyles.filterGroup}>
              <label className={mapStyles.filterLabel}>주요 서비스</label>
              <div className={mapStyles.pillButtonContainer}>
                {['24시간 상주', '개별 룸', '수영장', '펫 스파', '픽업 서비스', '넓은 운동장'].map(service => (
                  <button
                    key={service}
                    onClick={() => handleToggleFilter('hotelServices', service)}
                    className={`${mapStyles.pillButton} ${filters.hotelServices.includes(service) ? mapStyles.active : ''}`}
                  >
                    {service}
                  </button>
                ))}
              </div>
            </div>
            <div className={mapStyles.filterGroup}>
              <label className={mapStyles.filterLabel}>대상 동물</label>
              <div className={mapStyles.pillButtonContainer}>
                {['강아지', '고양이'].map(animal => (
                  <button
                    key={animal}
                    onClick={() => handleToggleFilter('targetAnimals', animal)}
                    className={`${mapStyles.pillButton} ${filters.targetAnimals.includes(animal) ? mapStyles.active : ''}`}
                  >
                    {animal}
                  </button>
                ))}
              </div>
            </div>
          </FilterSection>
        </div>
      </div>
      <div className="hotel-grid">
        <BusinessCardGrid items={hotels} itemType="hotel" />
      </div>

      {hotels.length > 0 && totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={goToPage}
        />
      )}
    </div>
  );
};

export default HotelPage;