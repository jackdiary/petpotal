import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import CommentSection from '../components/community/CommentSection';
import Button from '../components/ui/Button';
import styles from './PostDetail.module.css';

const PostDetail = () => {
  const { postId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [post, setPost] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userLiked, setUserLiked] = useState(false);

  useEffect(() => {
    fetchPost();
  }, [postId]);

  const fetchPost = async () => {
    try {
      const response = await fetch(`http://localhost:3001/api/community/posts/${postId}`);
      const data = await response.json();

      if (data.success) {
        setPost(data.data);
      } else {
        setError(data.message || '게시글을 불러올 수 없습니다.');
      }
    } catch (error) {
      console.error('게시글 조회 오류:', error);
      setError('게시글을 불러오는 중 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLike = async () => {
    if (!user) {
      alert('로그인이 필요합니다.');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:3001/api/community/posts/${postId}/like`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        }
      });

      const data = await response.json();

      if (data.success) {
        setUserLiked(data.data.liked);
        // 게시글 정보 다시 불러오기 (좋아요 수 업데이트)
        fetchPost();
      }
    } catch (error) {
      console.error('좋아요 처리 오류:', error);
    }
  };

  const handleEdit = () => {
    navigate(`/community/edit/${postId}`);
  };

  const handleDelete = async () => {
    if (!window.confirm('정말로 이 게시글을 삭제하시겠습니까?')) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:3001/api/community/posts/${postId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        }
      });

      const data = await response.json();

      if (data.success) {
        alert('게시글이 삭제되었습니다.');
        navigate('/community');
      } else {
        alert(data.message || '게시글 삭제에 실패했습니다.');
      }
    } catch (error) {
      console.error('게시글 삭제 오류:', error);
      alert('게시글 삭제 중 오류가 발생했습니다.');
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ko-KR') + ' ' + date.toLocaleTimeString('ko-KR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="container">
        <div className={styles.loading}>게시글을 불러오는 중...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container">
        <div className={styles.error}>
          <p>{error}</p>
          <Button variant="primary" onClick={() => navigate('/community')}>
            커뮤니티로 돌아가기
          </Button>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="container">
        <div className={styles.error}>
          <p>게시글을 찾을 수 없습니다.</p>
          <Button variant="primary" onClick={() => navigate('/community')}>
            커뮤니티로 돌아가기
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className={styles.postDetail}>
        {/* 게시글 헤더 */}
        <header className={styles.postHeader}>
          <div className={styles.breadcrumb}>
            <span onClick={() => navigate('/community')} className={styles.breadcrumbLink}>
              커뮤니티
            </span>
            <span className={styles.breadcrumbSeparator}>›</span> 
            <span onClick={() => navigate(`/community/${post.boardKey}`)} className={styles.breadcrumbLink}>
              {post.category_name}
            </span>
          </div>

          <div className={styles.categoryBadge}>
            <span className={styles.categoryIcon}>{post.category_icon}</span>
            {post.category_name}
          </div>

          <h1 className={styles.postTitle}>{post.title}</h1>

          <div className={styles.postMeta}>
            <div className={styles.authorInfo}>
              {post.author_image && (
                <img src={post.author_image} alt={post.author_name} className={styles.authorImage} />
              )}
              <div className={styles.authorDetails}>
                <span className={styles.authorName}>{post.author_name}</span>
                <div className={styles.postStats}>
                  <span>작성: {formatDate(post.created_at)}</span>
                  {post.updated_at !== post.created_at && (
                    <span>수정: {formatDate(post.updated_at)}</span>
                  )}
                  <span>조회: {post.views}</span>
                  <span>좋아요: {post.likes}</span>
                </div>
              </div>
            </div>

            {user && user.id === post.author_id && (
              <div className={styles.postActions}>
                <Button variant="secondary" size="small" onClick={handleEdit}>
                  수정
                </Button>
                <Button variant="danger" size="small" onClick={handleDelete}>
                  삭제
                </Button>
              </div>
            )}
          </div>
        </header>

        {/* 게시글 내용 */}
        <div className={styles.postContent}>
          {/* 에디터로 작성된 HTML을 렌더링합니다. */}
          <div className={styles.contentText} dangerouslySetInnerHTML={{ __html: post.content }} />
          {post.images && post.images.length > 0 && (
            <div className={styles.postImages}>
              {post.images.map((image, index) => (
                <img
                  key={index}
                  src={`http://localhost:3001${image}`}
                  alt={`게시글 이미지 ${index + 1}`}
                  className={styles.postImage}
                  onClick={(e) => {
                    // 이미지 클릭 시 새 창에서 크게 보기
                    window.open(e.target.src, '_blank');
                  }}
                />
              ))}
            </div>
          )}
        </div>

        {/* 게시글 푸터 */}
        <footer className={styles.postFooter}>
          <div className={styles.postInteractions}>
            <Button
              variant={userLiked ? "primary" : "secondary"}
              size="medium"
              onClick={handleLike}
              className={styles.likeButton}
            >
              👍 좋아요 {post.likes}
            </Button>
          </div>

          <div className={styles.postNavigation}>
            <Button
              variant="secondary" 
              onClick={() => navigate(`/community/${post.boardKey}`)}
            >
              목록으로
            </Button>
          </div>
        </footer>

        {/* 댓글 섹션 */}
        <CommentSection postId={postId} />
      </div>
    </div>
  );
};

export default PostDetail;