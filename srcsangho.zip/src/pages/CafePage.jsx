import React, { useEffect, useMemo, useState, useCallback } from 'react';
import CafeMapView from '../components/service/maps/CafeMapView';
import { Link } from 'react-router-dom'; // react-router-dom에서 Link를 import합니다.
import FilterSection from '../components/common/FilterSection';
import Pagination from '../components/common/Pagination';
import BusinessCardGrid from '../components/common/BusinessCardGrid';
import '../styles/cafe.css';
import mapStyles from './MapPage.module.css'; // 지도 스타일 import
import cafeData from '../data/cafe.json'; // 로컬 데이터 import
import useFetchAndFilterData from '../hooks/useFetchAndFilterData';

// const API_URL = 'http://localhost:3001/api/cafe'; // 로컬 데이터 사용으로 변경

const CafePage = () => {
  const [userLocation, setUserLocation] = useState(null);
  const [filters, setFilters] = useState({
    location: '',
    startTime: '',
    endTime: '',
    services: [],
    requiresReservation: null
  });

  const filterCafes = useCallback((dataToFilter) => {
    let cafes = dataToFilter;
    if (filters.location) {
      cafes = cafes.filter(cafe =>
        cafe.name.toLowerCase().includes(filters.location.toLowerCase()) ||
        cafe.address.toLowerCase().includes(filters.location.toLowerCase()));
    }
    if (filters.startTime && filters.endTime) {
      cafes = cafes.filter(cafe => {
        const cafeStart = parseInt((cafe.operatingHours?.start || '0').split(':')[0]);
        const cafeEnd = parseInt((cafe.operatingHours?.end || '0').split(':')[0]);
        const filterStart = parseInt(filters.startTime.split(':')[0]);
        const filterEnd = parseInt(filters.endTime.split(':')[0]);
        return cafeStart <= filterStart && cafeEnd >= filterEnd;
      });
    }
    if (filters.services.length > 0) {
      cafes = cafes.filter(cafe => filters.services.every(service => (cafe.services || []).includes(service)));
    }
    if (filters.requiresReservation !== null) {
      cafes = cafes.filter(cafe => cafe.requiresReservation === filters.requiresReservation);
    }
    return cafes;
  }, [filters]);

  const {
    filteredData: cafes,
    allData: allCafes,
    applyFilter,
    error,
    loading,
    currentPage,
    totalPages,
    totalItems,
    goToPage,
    searchTerm,
    updateSearchTerm
  } = useFetchAndFilterData(cafeData, (data) => data || [], { // 데이터 소스를 cafeData로 변경
    enablePagination: true,
    enableSearch: true,
    itemsPerPage: 6
  });

  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => setUserLocation({ lat: 37.5665, lng: 126.9780 })
    );
  }, []);

  useEffect(() => {
    applyFilter(filterCafes);
  }, [filters, allCafes, applyFilter, filterCafes]);

  const markers = useMemo(() => allCafes.map(cafe => ({
    id: cafe.id,
    lat: cafe.latitude,
    lng: cafe.longitude,
    name: cafe.name,
    // Add cafe-specific data
    amenities: cafe.services || ['wifi'],
    specialties: cafe.specialties || ['coffee'],
    isOpen: cafe.isOpen !== undefined ? cafe.isOpen : true,
    openingHours: cafe.operatingHours ? `${cafe.operatingHours.start}-${cafe.operatingHours.end}` : '09:00-22:00',
    rating: cafe.rating || 4.0,
    phone: cafe.phone || '',
    address: cafe.address || ''
  })), [allCafes]);

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  if (loading) {
    return <div className="pageContainer">카페 정보를 불러오는 중...</div>;
  }
  if (error) {
    return <div className="pageContainer" style={{ color: 'red' }}>오류: {error.message || '데이터를 불러오는 중 오류가 발생했습니다.'}</div>;
  }

  return (
    <div className="cafe-container">
      <header className="pageHeader">
        <h1 className="pageTitle">펫 카페</h1>
        <p className="pageSubtitle">반려동물과 함께 즐기는 특별한 카페 경험</p>
      </header>
      <div className={mapStyles.mapWrapper}>
        <CafeMapView 
          userLocation={userLocation} 
          markers={markers}
          filters={{
            amenities: filters.services,
            isOpenOnly: false
          }}
          onMarkerClick={(markerData) => {
            console.log('Cafe marker clicked:', markerData);
            // Could show detailed popup or navigate to detail page
          }}
        />
        <div className="filtersOnMap">
          <FilterSection
            locationPlaceholder="카페명이나 지역을 검색해보세요"
            onLocationChange={(value) => handleFilterChange('location', value)}>
            <div className="filterGroup">
              <label className="filterLabel">운영 시간</label>
              <div className="filterInputWrapper timeInputWrapper">
                <span className="timeIcon">⏰</span>
                <select value={filters.startTime} onChange={(e) => handleFilterChange('startTime', e.target.value)} className="filterInput">
                  <option value="">시작 시간</option>
                  {Array.from({ length: 24 }, (_, i) => {
                    const hour = i.toString().padStart(2, '0');
                    return <option key={hour} value={`${hour}:00`}>{hour}:00</option>;
                  })}
                </select>
                <span>~</span>
                <select value={filters.endTime} onChange={(e) => handleFilterChange('endTime', e.target.value)} className="filterInput">
                  <option value="">종료 시간</option>
                  {Array.from({ length: 24 }, (_, i) => {
                    const hour = i.toString().padStart(2, '0');
                    return <option key={hour} value={`${hour}:00`}>{hour}:00</option>;
                  })}
                </select>
              </div>
            </div>
            <div className="filterGroup">
              <label className="filterLabel">서비스</label>
              <div className="pillButtonContainer">
                {['애견음료', '대형견 가능', '야외 테라스', '고양이 전용 공간', '실내놀이터', '포토존', '굿즈', '보드게임', '수제 간식'].map(service => (
                  <button
                    key={service}
                    className={`pillButton ${filters.services.includes(service) ? 'active' : ''}`}
                    onClick={() => {
                      const newServices = filters.services.includes(service)
                        ? filters.services.filter(s => s !== service)
                        : [...filters.services, service];
                      handleFilterChange('services', newServices);
                    }}
                  >
                    {service}
                  </button>
                ))}
              </div>
            </div>
            <div className="filterGroup">
              <label className="filterLabel">예약</label>
              <div className="pillButtonContainer">
                <button
                  className={`pillButton ${filters.requiresReservation === false ? 'active' : ''}`}
                  onClick={() => handleFilterChange('requiresReservation', filters.requiresReservation === false ? null : false)}
                >
                  예약 불필요
                </button>
                <button
                  className={`pillButton ${filters.requiresReservation === true ? 'active' : ''}`}
                  onClick={() => handleFilterChange('requiresReservation', filters.requiresReservation === true ? null : true)}
                >
                  예약 필수
                </button>
              </div>
            </div>
          </FilterSection>
        </div>
      </div>

      {/* BusinessCardGrid 대신 직접 4열 그리드 구성 */}
      <div className="cafe-grid">
        <BusinessCardGrid items={cafes.map(c => ({ ...c, type: 'cafe' }))} />
      </div>

      {/* 페이징 */}
      {cafes.length > 0 && totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={goToPage}
        />
      )}
    </div>
  );
};

export default CafePage;
