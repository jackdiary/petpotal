import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import styles from './PensionDetailPage.module.css';
import Button from '../components/ui/Button';
import GuestPetSelector from '../components/pension/GuestPetSelector';
import { useUI } from '../contexts/UIContext';
import accommodationsData from '../data/accommodations.json';

const PetFriendlyLodgingDetailPage = () => {
  const { lodgingId } = useParams();
  const { setIsLoading } = useUI() || {};
  const [lodging, setLodging] = useState(null);
  const [error, setError] = useState(null);

  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [guests, setGuests] = useState(1);
  const [pets, setPets] = useState(0);
  const [showGuestSelector, setShowGuestSelector] = useState(false);

  useEffect(() => {
    const fetchLodging = async () => {
      if (setIsLoading) setIsLoading(true);
      setError(null);
      try {
        const lodgingData = accommodationsData.find(item => item.id.toString() === lodgingId);
        if (lodgingData) {
          setLodging(lodgingData);
        } else {
          setError('숙소 정보를 불러오는데 실패했습니다.');
        }
      } catch (err) {
        console.error('Failed to fetch lodging detail:', err);
        setError('숙소 정보를 불러오는데 실패했습니다.');
      } finally {
        if (setIsLoading) setIsLoading(false);
      }
    };

    if (lodgingId) {
      fetchLodging();
    }
  }, [lodgingId, setIsLoading]);

  const calculateNights = () => {
    if (startDate && endDate) {
      const diffTime = Math.abs(endDate - startDate);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > 0 ? diffDays : 0;
    }
    return 0;
  };

  const numberOfNights = calculateNights();
  const totalPrice = lodging ? lodging.price * numberOfNights : 0;
  const formatPrice = (price) => price.toLocaleString();

  const handleReservation = () => {
    if (!startDate || !endDate || !guests) {
      alert('체크인/체크아웃 날짜와 인원을 선택해주세요.');
      return;
    }
    if (numberOfNights <= 0) {
      alert('체크아웃 날짜는 체크인 날짜보다 늦어야 합니다.');
      return;
    }

    alert(`[Mock Reservation] ${lodging.name} 예약 요청:\n체크인: ${startDate.toLocaleDateString()}\n체크아웃: ${endDate.toLocaleDateString()}\n인원: ${guests}명\n반려동물: ${pets}마리\n총 ${numberOfNights}박, ${formatPrice(totalPrice)}원`);
  };

  if (!lodging && !error) {
    return <div className="container">숙소 정보를 불러오는 중...</div>;
  }

  if (error) {
    return (
      <div className="container">
        <div className={styles.notFound}>
          <h2>{error}</h2>
          <Link to="/pet-friendly-lodging">
            <Button variant="primary">숙소 목록으로 돌아가기</Button>
          </Link>
        </div>
      </div>
    );
  }

  if (!lodging) {
    return (
      <div>
        <div className={styles.notFound}>
          <h2>해당 숙소 정보를 찾을 수 없습니다.</h2>
          <p>주소가 올바른지 확인해주세요.</p>
          <Link to="/pet-friendly-lodging">
            <Button variant="primary">숙소 목록으로 돌아가기</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.detailPageContainer}>
      <section className={styles.carouselSection}>
        <Carousel
          showThumbs={false}
          infiniteLoop={true}
          autoPlay={true}
          interval={5000}
          showStatus={false}
        >
          {
            lodging.images ? 
            lodging.images.map((img, index) => (
              <div key={index}>
                <img src={img} alt={`${lodging.name} 이미지 ${index + 1}`} />
              </div>
            )) : 
            <div>
              <img src={lodging.image} alt={`${lodging.name} 이미지`} />
            </div>
          }
        </Carousel>
        <div className={styles.heroContent}>
          <p className={styles.pensionType}>{lodging.type}</p>
          <h1>{lodging.name}</h1>
          <p className={styles.pensionLocation}>{lodging.address}</p>
        </div>
      </section>

      <div className={styles.mainContent}>
        <div className={styles.infoColumn}>
          <div className={styles.infoBlock}>
            <h3>숙소 특징</h3>
            <div className={styles.tags}>
              {lodging.amenities.map(tag => <span key={tag} className={styles.tag}>{tag}</span>)}
            </div>
          </div>
          
          <div className={styles.infoBlock}>
            <h3>숙소 소개</h3>
            <p className={styles.description}>
              {lodging.name}에 오신 것을 환영합니다! 저희 숙소는 반려동물과 함께 편안한 휴식을 취할 수 있는 최적의 공간입니다. 
              (이 부분은 각 숙소의 실제 상세 설명으로 대체됩니다.)
            </p>
          </div>
        </div>

        <aside className={styles.bookingColumn}>
          <div className={styles.bookingBox}>
            <div className={styles.bookingSummary}>
              <p className={styles.price}><strong>₩{formatPrice(lodging.price)}</strong> / 1박</p>
            </div>
            
            <div className={styles.bookingInputs}>
              <div className={styles.datePickers}>
                <DatePicker
                  selected={startDate}
                  onChange={(date) => setStartDate(date)}
                  selectsStart
                  startDate={startDate}
                  endDate={endDate}
                  minDate={new Date()}
                  placeholderText="체크인 날짜"
                  className={styles.dateInput}
                  dateFormat="yyyy/MM/dd"
                />
                <DatePicker
                  selected={endDate}
                  onChange={(date) => setEndDate(date)}
                  selectsEnd
                  startDate={startDate}
                  endDate={endDate}
                  minDate={startDate || new Date()}
                  placeholderText="체크아웃 날짜"
                  className={styles.dateInput}
                  dateFormat="yyyy/MM/dd"
                />
              </div>
              <div style={{ position: 'relative' }}>
                <input
                  type="text"
                  readOnly
                  className={styles.guestInput}
                  onClick={() => setShowGuestSelector(!showGuestSelector)}
                  value={`게스트 ${guests}명${pets > 0 ? `, 펫 ${pets}마리` : ''}`}
                />
                {showGuestSelector && (
                  <GuestPetSelector
                    guests={guests}
                    setGuests={setGuests}
                    pets={pets}
                    setPets={setPets}
                    maxGuests={10}
                  />
                )}
              </div>
            </div>
            
            {numberOfNights > 0 && (
              <div className={styles.totalPrice}>
                <span>총 {numberOfNights}박</span>
                <span>₩{formatPrice(totalPrice)}</span>
              </div>
            )}
            
            <div className={styles.bookingActions}>
              <Button variant="primary" size="large" className={styles.bookingButton} onClick={handleReservation}>
                예약하기
              </Button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default PetFriendlyLodgingDetailPage;
