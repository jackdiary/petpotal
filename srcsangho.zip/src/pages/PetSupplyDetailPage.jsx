// src/pages/PetSupplyDetailPage.jsx
// 반려용품 상세 정보를 표시하는 페이지 컴포넌트
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom'; // URL 파라미터와 페이지 이동을 위한 훅
import styles from './PetSupplyDetailPage.module.css'; // 스타일 모듈 임포트
import petSuppliesData from '../data/petSupplies.json'; // 반려용품 데이터 임포트

const PetSupplyDetailPage = () => {
  const [product, setProduct] = useState(null); // 상품 정보 상태
  const [loading, setLoading] = useState(true); // 로딩 상태
  const [error, setError] = useState(null); // 오류 상태
  const { id } = useParams(); // URL에서 상품 ID 추출
  const navigate = useNavigate(); // 페이지 이동을 위한 훅

  // 컴포넌트 마운트 시 또는 ID 변경 시 상품 정보 로드
  useEffect(() => {
    fetchProduct();
  }, [id]);

  // 상품 정보를 가져오는 함수 (프론트엔드 전용)
  const fetchProduct = async () => {
    try {
      setLoading(true); // 로딩 시작
      
      // 백엔드 API 호출 대신 로컬 데이터에서 상품 검색
      // const response = await fetch(`http://localhost:3001/api/pet-supplies/${id}`);
      // const data = await response.json();
      
      // JSON 데이터에서 해당 ID의 상품 찾기
      const foundProduct = petSuppliesData.find(product => product.id.toString() === id);
      
      if (foundProduct) {
        setProduct(foundProduct); // 상품 정보 상태 업데이트
      } else {
        setError('상품을 찾을 수 없습니다.'); // 상품이 없을 경우 오류 설정
      }
    } catch (error) {
      console.error('상품 조회 실패:', error); // 오류 로그 출력
      setError('상품 정보를 불러오는 중 오류가 발생했습니다.'); // 오류 상태 설정
    } finally {
      setLoading(false); // 로딩 종료
    }
  };

  // 가격을 한국 원화 형식으로 포맷팅하는 함수
  const formatPrice = (price) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency', // 통화 스타일 적용
      currency: 'KRW' // 한국 원화 설정
    }).format(price);
  };

  // 이전 페이지로 돌아가는 함수
  const handleBackClick = () => {
    navigate(-1); // 브라우저 히스토리에서 이전 페이지로 이동
  };

  // 해당 카테고리 페이지로 이동하는 함수
  const handleCategoryClick = () => {
    navigate(`/pet-supplies/category/${product.category}`); // 카테고리별 상품 목록 페이지로 이동
  };

  if (loading) {
    return (
      <div className={styles.container}>
        <div className={styles.loading}>상품 정보를 불러오는 중...</div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className={styles.container}>
        <div className={styles.error}>
          <h2>오류가 발생했습니다</h2>
          <p>{error}</p>
          <button onClick={handleBackClick} className={styles.backButton}>
            돌아가기
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.breadcrumb}>
        <button onClick={() => navigate('/pet-supplies')} className={styles.breadcrumbLink}>
          반려용품
        </button>
        <span className={styles.separator}>&gt;</span>
        <button onClick={handleCategoryClick} className={styles.breadcrumbLink}>
          {product.category}
        </button>
        <span className={styles.separator}>&gt;</span>
        <span className={styles.currentPage}>{product.name}</span>
      </div>

      <div className={styles.productDetail}>
        <div className={styles.imageSection}>
          <div className={styles.mainImageWrapper}>
            <img
              src={product.imageUrl || 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=600'}
              alt={product.name}
              className={styles.mainImage}
            />
            {product.isBest && (
              <span className={styles.bestBadge}>BEST</span>
            )}
            {product.isFeatured && (
              <span className={styles.featuredBadge}>추천</span>
            )}
          </div>
        </div>

        <div className={styles.infoSection}>
          <div className={styles.category}>{product.category}</div>
          <h1 className={styles.productName}>{product.name}</h1>
          
          {product.brand && (
            <div className={styles.brand}>브랜드: {product.brand}</div>
          )}

          <div className={styles.rating}>
            {product.rating > 0 && (
              <>
                <span className={styles.stars}>
                  {'⭐'.repeat(Math.floor(product.rating))}
                </span>
                <span className={styles.ratingText}>{product.rating}</span>
                {product.reviewCount > 0 && (
                  <span className={styles.reviewCount}>({product.reviewCount}개 리뷰)</span>
                )}
              </>
            )}
          </div>

          <div className={styles.price}>
            <span className={styles.currentPrice}>{formatPrice(product.price)}</span>
          </div>

          <div className={styles.description}>
            <h3>상품 설명</h3>
            <p>{product.description}</p>
          </div>

          <div className={styles.stockInfo}>
            <span className={styles.stockLabel}>재고:</span>
            <span className={`${styles.stockStatus} ${product.stockQuantity > 0 ? styles.inStock : styles.outOfStock}`}>
              {product.stockQuantity > 0 ? `${product.stockQuantity}개 남음` : '품절'}
            </span>
          </div>

          <div className={styles.actions}>
            <button 
              className={styles.cartButton}
              disabled={product.stockQuantity === 0}
            >
              장바구니 담기
            </button>
            <button 
              className={styles.buyButton}
              disabled={product.stockQuantity === 0}
            >
              바로 구매
            </button>
          </div>

          <div className={styles.productInfo}>
            <h3>상품 정보</h3>
            <div className={styles.infoGrid}>
              <div className={styles.infoItem}>
                <span className={styles.infoLabel}>카테고리</span>
                <span className={styles.infoValue}>{product.category}</span>
              </div>
              {product.brand && (
                <div className={styles.infoItem}>
                  <span className={styles.infoLabel}>브랜드</span>
                  <span className={styles.infoValue}>{product.brand}</span>
                </div>
              )}
              <div className={styles.infoItem}>
                <span className={styles.infoLabel}>등록일</span>
                <span className={styles.infoValue}>
                  {new Date(product.createdAt).toLocaleDateString('ko-KR')}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className={styles.backToList}>
        <button onClick={handleBackClick} className={styles.backButton}>
          목록으로 돌아가기
        </button>
      </div>
    </div>
  );
};

export default PetSupplyDetailPage;