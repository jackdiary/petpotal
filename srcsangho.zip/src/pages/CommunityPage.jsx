// src/pages/CommunityPage.jsx
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Link, useParams } from 'react-router-dom';
import communityStyles from './CommunityPage.module.css';
import layoutStyles from './commonLayout.module.css';

import BoardNav from '../components/community/BoardNav';
import Board from '../components/community/Board';
import Button from '../components/ui/Button';
import Pagination from '../components/common/Pagination'; // Pagination 컴포넌트를 사용합니다.
import { mockDataService } from '../utils/mockDataService';

// Hardcoded board data for navigation (can be fetched from API later if needed)
const boardsMeta = {
  'free-talk': { name: '자유게시판', description: '반려동물에 대한 이야기를 자유롭게 나눠보세요.' },
  'pet-showcase': { name: '펫 자랑 게시판', description: '사랑스러운 반려동물의 사진과 영상을 마음껏 자랑해주세요.' },
  'info-share': { name: '정보공유 게시판', description: '사료, 간식, 병원, 꿀팁 등 유용한 정보를 공유해요.' },
  'qna': { name: 'Q&A 게시판', description: '반려동물을 키우면서 궁금한 점을 물어보세요.' },
  'adoption': { name: '나눔/분양 게시판', description: '따뜻한 마음을 나눠주세요.' },
  'meetups': { name: '산책/모임 게시판', description: '지역별 산책 친구, 정기 모임을 찾아보세요.' },
  'missing': { name: '실종/보호 게시판', description: '소중한 가족을 찾습니다.' },
  'reviews': { name: '펫 동반 장소 후기', description: '함께 갈 수 있는 멋진 장소를 추천해주세요.' },
};

const POSTS_PER_PAGE = 5;

const CommunityPage = () => {
  console.log('CommunityPage rendered'); // New: Confirm component rendering
  const { boardKey: activeBoardKey = 'free-talk' } = useParams();
  const [posts, setPosts] = useState([]);
  const [totalPosts, setTotalPosts] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Initialize mock posts data if not already present
    mockDataService.initialize('posts', [
      { id: 1, categoryKey: 'free-talk', title: '첫 번째 자유 게시글', content: '자유롭게 이야기해요.', author_name: 'User1', createdAt: '2023-01-01T10:00:00Z', views: 10, likes: 2 },
      { id: 2, categoryKey: 'pet-showcase', title: '우리 강아지 자랑', content: '너무 귀엽죠?', author_name: 'User2', createdAt: '2023-01-02T11:00:00Z', views: 15, likes: 5 },
      { id: 3, categoryKey: 'info-share', title: '강아지 사료 추천', content: '이 사료 정말 좋아요.', author_name: 'User3', createdAt: '2023-01-03T12:00:00Z', views: 20, likes: 8 },
      { id: 4, categoryKey: 'free-talk', title: '두 번째 자유 게시글', content: '또 다른 이야기.', author_name: 'User1', createdAt: '2023-01-04T13:00:00Z', views: 5, likes: 1 },
      { id: 5, categoryKey: 'qna', title: '고양이 행동 질문', content: '왜 이러는 걸까요?', author_name: 'User4', createdAt: '2023-01-05T14:00:00Z', views: 12, likes: 3 },
      { id: 6, categoryKey: 'free-talk', title: '세 번째 자유 게시글', content: '세 번째 이야기.', author_name: 'User5', createdAt: '2023-01-06T15:00:00Z', views: 8, likes: 0 },
      { id: 7, categoryKey: 'pet-showcase', title: '우리 고양이 사진', content: '심쿵주의!', author_name: 'User6', createdAt: '2023-01-07T16:00:00Z', views: 22, likes: 10 },
      { id: 8, categoryKey: 'info-share', title: '펫 보험 정보', content: '필요한 정보 공유해요.', author_name: 'User7', createdAt: '2023-01-08T17:00:00Z', views: 18, likes: 6 },
      { id: 9, categoryKey: 'free-talk', title: '네 번째 자유 게시글', content: '마지막 이야기.', author_name: 'User8', createdAt: '2023-01-09T18:00:00Z', views: 7, likes: 2 },
      { id: 10, categoryKey: 'qna', title: '강아지 훈련 질문', content: '어떻게 가르쳐야 할까요?', author_name: 'User9', createdAt: '2023-01-10T19:00:00Z', views: 11, likes: 4 },
      { id: 11, categoryKey: 'free-talk', title: '다섯 번째 자유 게시글', content: '다섯 번째 이야기.', author_name: 'User10', createdAt: '2023-01-11T20:00:00Z', views: 9, likes: 3 },
      { id: 12, categoryKey: 'pet-showcase', title: '우리 햄스터 자랑', content: '작지만 소중해요.', author_name: 'User11', createdAt: '2023-01-12T21:00:00Z', views: 13, likes: 7 },
    ]);

    const timeoutId = setTimeout(() => {
      fetchPosts();
    }, 300);
    
    return () => {
      clearTimeout(timeoutId);
    };
  }, [activeBoardKey, searchTerm, currentPage]);

  const fetchPosts = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await mockDataService.getAll('posts');
      if (response.success) {
        let allPosts = response.data;

        // Filter by boardKey
        allPosts = allPosts.filter(post => post.categoryKey === activeBoardKey);

        // Filter by search term
        if (searchTerm) {
          allPosts = allPosts.filter(post =>
            post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            post.content.toLowerCase().includes(searchTerm.toLowerCase())
          );
        }

        // Sort by createdAt (newest first)
        allPosts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        const totalItems = allPosts.length;
        const totalPagesCount = Math.ceil(totalItems / POSTS_PER_PAGE);
        const startIndex = (currentPage - 1) * POSTS_PER_PAGE;
        const endIndex = startIndex + POSTS_PER_PAGE;
        const paginatedPosts = allPosts.slice(startIndex, endIndex);

        setPosts(paginatedPosts);
        setTotalPosts(totalItems);
        setTotalPages(totalPagesCount);
      } else {
        setError(new Error(response.message || '게시글을 불러오는 데 실패했습니다.'));
      }
    } catch (err) {
      console.error('Error fetching posts:', err);
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  const totalPages = Math.ceil(totalPosts / POSTS_PER_PAGE);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    const searchInput = e.target.elements.searchInput.value;
    setSearchTerm(searchInput);
    setCurrentPage(1); // 검색 시 첫 페이지로 이동
  };

  if (loading) {
    return <div>게시글을 불러오는 중...</div>;
  }

  if (error) {
    return <div style={{ color: 'red' }}>오류: {error.message || '데이터를 불러오는 중 오류가 발생했습니다.'}</div>;
  }
    
  const activeBoardData = boardsMeta[activeBoardKey];
    
  if (!activeBoardData) {
      return <div>게시판을 찾을 수 없습니다.</div>;
  }


  return (
    <div className={layoutStyles.pageContainer}>
      <main className={layoutStyles.pageLayout}>
        <div className={layoutStyles.sidebar}>
          <BoardNav
            boards={boardsMeta}
            activeBoard={activeBoardKey}
          />
        </div>
        <div className={layoutStyles.mainContent}>
          <header className={communityStyles.boardHeader}>
            <h1>{activeBoardData.name}</h1>
            <p>{activeBoardData.description}</p>
          </header>
          <div className={communityStyles.boardControls}>
            <form className={communityStyles.searchBar} onSubmit={handleSearch}>
              <input type="text" name="searchInput" placeholder="궁금한 내용을 검색해보세요." />
              <Button type="submit" variant="secondary" size="medium">검색</Button>
            </form>
            <Link to={`/community/${activeBoardKey}/new`}>
              <Button variant="primary" size="medium">글쓰기</Button>
            </Link>
          </div>
          
          <Board
            notices={[]} // Pass an empty array for notices
            posts={posts}
            boardKey={activeBoardKey}
          />
          
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={handlePageChange}
          />
        </div>
      </main>
    </div>
  );
};

export default CommunityPage;