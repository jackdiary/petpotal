// src/context/MaintenanceContext.jsx

import React, { createContext, useContext, useState, useEffect } from 'react'; // React와 컨텍스트, 상태 관리를 위한 훅들을 가져옵니다.



const MaintenanceContext = createContext(); // 유지보수 상태를 공유하기 위한 컨텍스트를 생성합니다.



const defaultSettings = { // 유지보수 설정의 기본값입니다.

  startDate: '', // 시작 날짜

  startTime: '', // 시작 시간

  endDate: '', // 종료 날짜

  endTime: '', // 종료 시간

  message: 'Service is temporarily unavailable while we perform scheduled maintenance. Please try again later.', // 유지보수 메시지

  reason: 'Scheduled Maintenance', // 유지보수 사유

  isActive: false // 활성화 여부

};



const parseDate = (date, time) => { // 날짜와 시간 문자열을 Date 객체로 변환하는 함수입니다.

  if (!date || !time) { // 날짜나 시간이 없으면

    return null; // null을 반환합니다.

  }

  const parsed = new Date(`${date}T${time}`); // 'YYYY-MM-DDTHH:MM' 형식으로 합쳐 Date 객체를 생성합니다.

  return Number.isNaN(parsed.getTime()) ? null : parsed; // 유효하지 않은 날짜면 null, 아니면 Date 객체를 반환합니다.

};



const computeIsActive = (settings) => { // 설정 객체를 기반으로 현재 유지보수 모드인지 계산하는 함수입니다.

  if (!settings?.isActive) { // 설정에서 '활성' 상태가 아니면

    return false; // 즉시 false를 반환합니다.

  }



  const start = parseDate(settings.startDate, settings.startTime); // 시작 시간을 Date 객체로 변환합니다.

  const end = parseDate(settings.endDate, settings.endTime); // 종료 시간을 Date 객체로 변환합니다.



  if (!start || !end) { // 시작 또는 종료 시간이 유효하지 않으면

    return settings.isActive; // 설정의 isActive 값을 그대로 따릅니다. (수동 제어 모드)

  }



  const now = new Date(); // 현재 시간을 가져옵니다.

  if (now > end) { // 현재 시간이 종료 시간을 지났으면

    return false; // 유지보수 모드가 아닙니다.

  }



  return now >= start && now <= end; // 현재 시간이 시작과 종료 사이일 때만 true를 반환합니다.

};



export const useMaintenance = () => { // 유지보수 컨텍스트를 쉽게 사용하기 위한 커스텀 훅입니다.

  const context = useContext(MaintenanceContext); // MaintenanceContext의 값을 가져옵니다.

  if (!context) { // 컨텍스트가 없으면 (Provider 외부에서 사용 시)

    throw new Error('useMaintenance must be used within a MaintenanceProvider'); // 에러를 발생시킵니다.

  }

  return context; // 컨텍스트 값을 반환합니다.

};



export const MaintenanceProvider = ({ children }) => { // 컨텍스트를 제공하는 Provider 컴포넌트입니다.

  const [isMaintenanceMode, setIsMaintenanceMode] = useState(false); // 현재 유지보수 모드 여부를 저장하는 상태입니다.

  const [maintenanceSettings, setMaintenanceSettings] = useState(defaultSettings); // 유지보수 설정 객체를 저장하는 상태입니다.

  const [isLoading, setIsLoading] = useState(false); // 데이터 로딩 상태를 관리합니다.



  const applySettings = (settings) => { // 새로운 설정을 받아 상태를 업데이트하는 함수입니다.

    const merged = { ...defaultSettings, ...settings }; // 기본 설정과 새 설정을 병합합니다.

    setMaintenanceSettings(merged); // 병합된 설정으로 상태를 업데이트합니다.

    setIsMaintenanceMode(computeIsActive(merged)); // 계산된 유지보수 모드 상태를 업데이트합니다.

    return merged; // 병합된 설정을 반환합니다.

  };



  const fetchMaintenanceSettings = async () => { // 서버에서 유지보수 설정을 가져오는 비동기 함수입니다.

    setIsLoading(true); // 로딩 상태를 true로 설정합니다.
    try { 
      // Mock fetching from localStorage
      const storedSettings = localStorage.getItem('maintenanceSettings');
      if (storedSettings) {
        applySettings(JSON.parse(storedSettings));
      } else {
        applySettings(defaultSettings);
      }

    } catch (error) { // 요청 중 오류가 발생하면

      console.warn('Failed to fetch maintenance settings:', error); // 콘솔에 경고를 기록합니다.

      applySettings(defaultSettings); // 기본 설정으로 상태를 초기화합니다.

    } finally { // 성공 여부와 관계없이 항상 실행됩니다.

      setIsLoading(false); // 로딩 상태를 false로 설정합니다。

    }

  };



  const updateMaintenanceSettings = async (newSettings) => { // 관리자가 유지보수 설정을 업데이트하는 비동기 함수입니다.

    try {
      // Mock updating to localStorage
      localStorage.setItem('maintenanceSettings', JSON.stringify(newSettings));
      const updated = applySettings(newSettings);
      return updated;

    } catch (error) { // 요청 중 오류가 발생하면

      console.error('Failed to update maintenance settings:', error); // 콘솔에 오류를 기록합니다.

      throw error; // 에러를 다시 던져 호출한 쪽에서 처리할 수 있도록 합니다.

    }

  };



  const setMaintenanceMode = async (isActive) => { // 유지보수 모드를 켜고 끄는 간편 함수입니다.

    const updatedSettings = { ...maintenanceSettings, isActive }; // 현재 설정에서 isActive 값만 변경합니다.

    return updateMaintenanceSettings(updatedSettings); // 변경된 설정으로 서버에 업데이트를 요청합니다.

  };



  const getTimeUntilMaintenanceEnd = () => { // 유지보수 종료까지 남은 시간을 계산하는 함수입니다.

    if (!isMaintenanceMode) { // 유지보수 모드가 아니면

      return null; // null을 반환합니다.

    }

    const end = parseDate(maintenanceSettings.endDate, maintenanceSettings.endTime); // 종료 시간을 Date 객체로 변환합니다.

    if (!end) { // 유효하지 않으면

      return null; // null을 반환합니다.

    }



    const now = new Date(); // 현재 시간을 가져옵니다.

    const diff = end.getTime() - now.getTime(); // 종료 시간과 현재 시간의 차이(ms)를 계산합니다.

    if (diff <= 0) { // 이미 종료되었으면

      return null; // null을 반환합니다。

    }



    const hours = Math.floor(diff / (1000 * 60 * 60)); // 남은 시간을 시간 단위로 계산합니다.

    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)); // 남은 시간을 분 단위로 계산합니다.

    return { hours, minutes, endDateTime: end }; // 남은 시간과 종료 시각을 객체로 반환합니다.

  };



  useEffect(() => { // 컴포넌트가 처음 마운트될 때 실행됩니다.

    fetchMaintenanceSettings(); // 유지보수 설정을 불러옵니다.

  }, []); // 빈 배열을 의존성으로 전달하여 최초 렌더링 시에만 실행되도록 합니다.



  useEffect(() => { // maintenanceSettings 상태가 변경될 때마다 실행됩니다.

    const interval = setInterval(() => { // 1분(60000ms)마다 주기적으로 실행되는 인터벌을 설정합니다.

      setIsMaintenanceMode(computeIsActive(maintenanceSettings)); // 현재 시간에 따라 유지보수 모드 상태를 다시 계산하여 업데이트합니다.

    }, 60000);



    return () => clearInterval(interval); // 컴포넌트가 언마운트될 때 인터벌을 정리합니다.

  }, [maintenanceSettings]); // maintenanceSettings가 변경될 때마다 이 효과를 다시 설정합니다.



  const value = { // 컨텍스트를 통해 하위 컴포넌트에 제공할 값들입니다.

    isMaintenanceMode, // 유지보수 모드 여부

    isLoading, // 로딩 상태

    maintenanceSettings, // 유지보수 설정 객체

    refreshMaintenanceSettings: fetchMaintenanceSettings, // 설정 새로고침 함수

    updateMaintenanceSettings, // 설정 업데이트 함수

    setMaintenanceMode, // 모드 활성화/비활성화 함수

    getTimeUntilMaintenanceEnd, // 남은 시간 계산 함수

    checkMaintenanceStatus: () => computeIsActive(maintenanceSettings) // 현재 상태 즉시 확인 함수

  };



  return ( // 컨텍스트 Provider로 자식 컴포넌트들을 감싸고, value를 전달합니다.

    <MaintenanceContext.Provider value={value}>

      {children}

    </MaintenanceContext.Provider>

  );

};



export default MaintenanceContext; // 컨텍스트 객체를 내보냅니다.